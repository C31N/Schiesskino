from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

import numpy as np
import pygame

from laser_arcade.config import Settings
from laser_arcade.diagnostic_ui import LaserDiagnosticUI
from laser_arcade.laser_tracker import LaserDetection
from laser_arcade.weapon_calibration import fit_weapon_calibration


class DummyTracker:
    actual_width = 640
    actual_height = 360
    actual_fps = 30.0
    processing_fps = 30.0

    def __init__(self) -> None:
        self.reset_count = 0
        self.moorhuhn_filter_enabled = False

    def reset_state(self) -> None:
        self.reset_count += 1

    def set_moorhuhn_filter(self, enabled: bool) -> None:
        self.moorhuhn_filter_enabled = enabled


class SightingWorkflowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        pygame.init()
        pygame.display.set_mode((1024, 768))

    @classmethod
    def tearDownClass(cls) -> None:
        pygame.quit()

    @staticmethod
    def _new_ui(weapon_calibration_path: Path | None = None) -> LaserDiagnosticUI:
        ui = LaserDiagnosticUI(
            pygame.Surface((1024, 768)),
            Settings(),
            DummyTracker(),
            weapon_calibration_path=weapon_calibration_path,
            target_history_path=None,
            water_alarm_leaderboard_path=None,
        )
        ui.aligner.phase = "success"
        ui.aligner.homography = np.eye(3, dtype=np.float32)
        ui.view_mode = "target"
        ui.armed_at = 0.0
        return ui

    @staticmethod
    def _fire(
        ui: LaserDiagnosticUI,
        point: tuple[int, int],
        now: float,
        *,
        peak_red_excess: int = 110,
        peak_delta: int = 140,
    ) -> None:
        ui.update(
            LaserDetection(
                point=point,
                area=4.0,
                confidence=0.95,
                frame_ts=now,
                mask_preview=None,
                frame_preview=None,
                shot=True,
                peak_red_excess=peak_red_excess,
                peak_delta=peak_delta,
            ),
            now,
        )

    def test_five_center_and_three_per_corner_reach_final_evaluation(self) -> None:
        ui = self._new_ui()

        expected_counts = [5, 3, 3, 3, 3]
        now = 100.0
        for step, required in enumerate(expected_counts):
            target = ui._sighting_stages()[step][3]
            for shot_index in range(required):
                point = (target[0] + shot_index, target[1] - shot_index)
                self._fire(ui, point, now)
                now += 1.0

            self.assertEqual(len(ui.completed_groups[step]), required)
            if step < 4:
                self.assertEqual(ui.sighting_phase, "evaluation")
                # Das gesamte Auswertungsfenster dient als große Weiter-Fläche.
                self._fire(ui, ui._stage_evaluation_rect().center, now)
                now += 1.0
                ui.armed_at = 0.0
            else:
                # Der letzte Schuss öffnet ohne weiteren Bedientreffer die
                # Gesamtauswertung.
                self.assertEqual(ui.sighting_phase, "complete")

        self.assertEqual(ui.sighting_phase, "complete")
        self.assertEqual([len(group) for group in ui.completed_groups], expected_counts)
        self.assertEqual(len(ui.shots), 17)
        self.assertTrue(ui.weapon_calibration.active)

        self._fire(ui, ui._complete_evaluation_rect().center, now)
        self.assertEqual(ui.sighting_phase, "shooting")
        self.assertEqual(len(ui.shots), 0)

    def test_sighting_calibrates_weapon_offset_and_persists_it(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "weapon_calibration.json"
            ui = self._new_ui(path)
            deviation = (80, -45)
            now = 100.0

            for step, required in enumerate((5, 3, 3, 3, 3)):
                target = ui._sighting_stages()[step][3]
                for _ in range(required):
                    self._fire(
                        ui,
                        (target[0] + deviation[0], target[1] + deviation[1]),
                        now,
                    )
                    now += 1.0
                if step < 4:
                    self._fire(ui, ui._stage_evaluation_rect().center, now)
                    now += 1.0
                    ui.armed_at = 0.0

            self.assertTrue(path.exists())
            self.assertAlmostEqual(ui.weapon_calibration.offset_x, -80.0)
            self.assertAlmostEqual(ui.weapon_calibration.offset_y, 45.0)

            reloaded = self._new_ui(path)
            self.assertTrue(reloaded.weapon_calibration.active)
            self.assertEqual(
                reloaded.weapon_calibration.apply((580, 339), (1024, 768)),
                (500, 384),
            )

            # Die gespeicherte Korrektur wird vor der Bedienlogik angewendet:
            # Der rohe Laserpunkt darf abweichen und trifft trotzdem die Karte.
            reloaded._show_menu()
            reloaded.armed_at = 0.0
            cans_card = reloaded._menu_entries()[1][0]
            raw_aim = (
                cans_card.centerx + deviation[0],
                cans_card.centery + deviation[1],
            )
            self._fire(reloaded, raw_aim, now + 1.0)
            self.assertEqual(reloaded.view_mode, "cans")

            # Beim erneuten Einschießen bleiben dagegen die Rohkoordinaten in
            # der Auswertung erhalten, damit nicht die alte Korrektur vermessen wird.
            reloaded._start_sighting()
            reloaded.armed_at = 0.0
            raw_target = (600, 420)
            self._fire(reloaded, raw_target, now + 2.0)
            self.assertEqual(reloaded.stage_shots[-1].screen_point, raw_target)

    def test_inconsistent_sighting_groups_are_rejected(self) -> None:
        targets = [(512, 404), (122, 184), (902, 184), (902, 599), (122, 599)]
        contradictory_offsets = [(0, 0), (180, 0), (-180, 0), (0, 170), (0, -170)]
        groups = [
            [(target[0] - offset[0], target[1] - offset[1])] * 3
            for target, offset in zip(targets, contradictory_offsets)
        ]

        with self.assertRaisesRegex(ValueError, "zu unterschiedlich"):
            fit_weapon_calibration(groups, targets, (1024, 768))

    def test_every_visible_control_can_be_operated_by_laser(self) -> None:
        ui = self._new_ui()
        target = ui._sighting_stages()[0][3]
        self._fire(ui, target, 100.0)
        self.assertEqual(len(ui.shots), 1)

        self._fire(ui, ui.target_clear_button.center, 101.0)
        self.assertEqual(len(ui.shots), 0)
        ui.armed_at = 0.0

        self._fire(ui, ui.target_menu_button.center, 102.0)
        self.assertEqual(ui.view_mode, "menu")
        ui.armed_at = 0.0

        self._fire(ui, ui.menu_sighting_button.center, 103.0)
        self.assertEqual(ui.view_mode, "target")
        ui.armed_at = 0.0

        self._fire(ui, ui.target_live_button.center, 104.0)
        self.assertEqual(ui.view_mode, "diagnostic")
        ui.armed_at = 0.0

        self._fire(ui, ui.diagnostic_target_button.center, 105.0)
        self.assertEqual(ui.view_mode, "menu")
        ui.armed_at = 0.0

        self._fire(ui, ui.menu_sighting_button.center, 106.0)
        ui.armed_at = 0.0
        self._fire(ui, ui.target_align_button.center, 107.0)
        self.assertTrue(ui.aligner.active)

    def test_camera_view_program_close_can_be_operated_by_pistol(self) -> None:
        ui = self._new_ui()
        ui._show_menu()
        ui.armed_at = 0.0

        self._fire(ui, ui.menu_camera_button.center, 100.0)
        self.assertEqual(ui.view_mode, "diagnostic")
        ui.armed_at = 0.0

        self._fire(ui, ui.diagnostic_close_button.center, 101.0)
        self.assertTrue(ui.close_requested)
        self.assertFalse(ui.handle_event(pygame.event.Event(pygame.NOEVENT)))

        self.assertGreater(ui.diagnostic_close_button.top, ui.clear_button.top)
        self.assertLessEqual(ui.diagnostic_close_button.bottom, ui.screen.get_height())

    def test_all_six_game_cards_are_available_and_fit(self) -> None:
        ui = self._new_ui()
        ui._show_menu()
        ui.armed_at = 0.0

        for rect, name, _, available in ui._menu_entries():
            fitted = ui._fitted_card_font(name, rect.width - 36)
            self.assertLessEqual(fitted.size(name)[0], rect.width - 36)
            self.assertTrue(available)

    def test_cans_game_can_be_selected_started_and_left_with_pistol(self) -> None:
        ui = self._new_ui()
        ui._show_menu()
        ui.armed_at = 0.0

        cans_card = ui._menu_entries()[1][0]
        self._fire(ui, cans_card.center, 100.0)
        self.assertEqual(ui.view_mode, "cans")
        self.assertEqual(ui.cans_game.state, "ready")
        ui.armed_at = 0.0

        self._fire(ui, ui.cans_game.start_card.center, 101.0)
        self.assertEqual(ui.cans_game.state, "countdown")
        ui.update(
            LaserDetection(None, 0.0, 0.0, 101.1, None, None),
            101.1,
        )
        ui.armed_at = 0.0

        self._fire(ui, ui.cans_game.menu_button.center, 102.0)
        self.assertEqual(ui.view_mode, "menu")

    def test_new_games_can_be_selected_and_left_with_pistol(self) -> None:
        ui = self._new_ui()
        expected = (
            (0, "clay", ui.clay_game),
            (2, "timed", ui.timed_game),
            (4, "reaction", ui.reaction_game),
            (5, "range", ui.target_range_game),
        )
        now = 100.0
        for card_index, view_mode, game in expected:
            ui._show_menu()
            ui.armed_at = 0.0
            self._fire(ui, ui._menu_entries()[card_index][0].center, now)
            self.assertEqual(ui.view_mode, view_mode)
            ui.armed_at = 0.0
            self._fire(ui, game.menu_button.center, now + 0.5)
            self.assertEqual(ui.view_mode, "menu")
            now += 1.0

    def test_standard_game_state_transition_resets_detector_and_arms_later(self) -> None:
        ui = self._new_ui()
        ui._start_standard_game("range", ui.target_range_game, "Zielscheibe")
        reset_before = ui.tracker.reset_count

        ui.target_range_game.state = "result"
        ui.target_range_game.result_until = 200.0
        ui.update(
            LaserDetection(None, 0.0, 0.0, 120.0, None, None),
            120.0,
        )

        self.assertEqual(ui.tracker.reset_count, reset_before + 1)
        self.assertEqual(ui.armed_at, 120.4)
        self.assertEqual(
            ui.standard_game_states[id(ui.target_range_game)],
            "result",
        )

    def test_water_alarm_starts_without_name_and_can_be_left_with_pistol(self) -> None:
        ui = self._new_ui()
        ui._show_menu()
        ui.armed_at = 0.0

        water_card = ui._menu_entries()[3][0]
        self._fire(ui, water_card.center, 100.0)
        self.assertEqual(ui.view_mode, "water")
        self.assertEqual(ui.water_alarm_game.state, "ready")
        ui.armed_at = 0.0

        self._fire(ui, ui.water_alarm_game.ready_start_button.center, 102.0)
        self.assertEqual(ui.water_alarm_game.state, "countdown")
        ui.update(LaserDetection(None, 0.0, 0.0, 106.0, None, None), 106.0)
        self.assertEqual(ui.water_alarm_game.state, "playing")
        self.assertFalse(ui.tracker.moorhuhn_filter_enabled)
        ui.armed_at = 0.0

        self._fire(ui, ui.water_alarm_game.menu_button.center, 107.0)
        self.assertEqual(ui.view_mode, "menu")

    def test_water_alarm_optional_post_game_name_accepts_weaker_real_laser(self) -> None:
        ui = self._new_ui()
        ui._show_menu()
        ui.armed_at = 0.0

        self._fire(ui, ui._menu_entries()[3][0].center, 100.0)
        game = ui.water_alarm_game
        game.score = 1000
        game.hits = 5
        game.shots = 6
        game._finish(100.5)
        ui.standard_game_states[id(game)] = "result"
        ui.armed_at = 0.0

        self._fire(ui, game.result_repeat_button.center, 101.0)
        self.assertEqual(game.state, "name_entry")
        ui.standard_game_states[id(game)] = "name_entry"
        ui.armed_at = 0.0

        key, rect = game.key_buttons[1]
        self._fire(
            ui,
            rect.center,
            101.0,
            peak_red_excess=40,
            peak_delta=45,
        )
        self.assertEqual(game.player_name, key)

    def test_water_alarm_logo_appearance_cannot_be_counted_as_shot(self) -> None:
        ui = self._new_ui()
        ui._start_standard_game("water", ui.water_alarm_game, "Wasser-Alarm")
        game = ui.water_alarm_game
        game.state = "playing"
        game.player_name = "TEST"
        game.play_started = 100.0
        game.last_update = 100.0
        game.deadline = 160.0
        logo = game._spawn_target("logo", 100.0)
        ui.standard_game_states[id(game)] = "playing"
        ui.armed_at = 0.0

        self._fire(ui, logo.center, 100.1)

        self.assertEqual(game.shots, 0)
        self.assertTrue(ui.standard_visual_transitions[id(game)])

    def test_cursor_hides_after_inactivity_and_returns_on_mouse_activity(self) -> None:
        ui = self._new_ui()
        ui.xfixes_cursor = mock.Mock()
        ui.physical_mouse_connected = True
        ui._mark_mouse_activity(now=10.0)
        ui.xfixes_cursor.show.assert_called_once()
        ui._update_cursor_visibility(now=11.0)
        self.assertFalse(ui.cursor_hidden)

        ui._update_cursor_visibility(now=11.6)
        self.assertTrue(ui.cursor_hidden)
        ui.xfixes_cursor.hide.assert_called_once_with()

        ui._mark_mouse_activity(now=12.0)
        self.assertFalse(ui.cursor_hidden)
        self.assertEqual(ui.xfixes_cursor.show.call_count, 2)

        ui._update_cursor_visibility(now=14.0)
        self.assertTrue(ui.cursor_hidden)
        position = ui.last_mouse_position
        ui.handle_event(pygame.event.Event(pygame.MOUSEMOTION, pos=position))
        self.assertTrue(ui.cursor_hidden)

        moved = (position[0] + 3, position[1])
        ui.handle_event(pygame.event.Event(pygame.MOUSEMOTION, pos=moved))
        self.assertFalse(ui.cursor_hidden)

    def test_mouse_hotplug_releases_cursor_and_unplug_hides_it(self) -> None:
        ui = self._new_ui()
        ui.physical_mouse_connected = False
        ui.cursor_hidden = True
        ui.last_mouse_probe = 0.0
        old_xfixes = mock.Mock()
        ui.xfixes_cursor = old_xfixes
        new_xfixes = mock.Mock()

        with (
            mock.patch.object(ui, "_physical_mouse_connected", return_value=True),
            mock.patch(
                "laser_arcade.diagnostic_ui.XFixesCursorController",
                return_value=new_xfixes,
            ),
        ):
            ui._update_cursor_visibility(now=3.0)

        self.assertTrue(ui.physical_mouse_connected)
        self.assertFalse(ui.cursor_hidden)
        self.assertEqual(ui.last_mouse_activity, 3.0)
        old_xfixes.close.assert_called_once_with()
        self.assertIs(ui.xfixes_cursor, new_xfixes)

        with mock.patch.object(ui, "_physical_mouse_connected", return_value=False):
            ui._update_cursor_visibility(now=6.0)

        self.assertFalse(ui.physical_mouse_connected)
        self.assertTrue(ui.cursor_hidden)

    def test_real_mouse_motion_forces_pygame_cursor_visible(self) -> None:
        ui = self._new_ui()
        ui.physical_mouse_connected = True
        ui.cursor_hidden = False
        ui.xfixes_cursor = mock.Mock()

        with mock.patch("pygame.mouse.set_visible") as set_visible:
            ui._mark_mouse_activity(now=20.0)

        set_visible.assert_called_once_with(True)
        ui.xfixes_cursor.show.assert_not_called()
        self.assertFalse(ui.cursor_hidden)

    def test_bluetooth_keyboard_mouse_channel_is_detected_without_by_id_link(self) -> None:
        bluetooth_combo = """
N: Name="Bluetooth 5.1 Keyboard"
H: Handlers=sysrq kbd leds event5

N: Name="Bluetooth 5.1 Keyboard Mouse"
H: Handlers=mouse0 event6
"""
        keyboard_and_hdmi_only = """
N: Name="vc4-hdmi-0"
H: Handlers=kbd event0
B: REL=3

N: Name="Bluetooth Keyboard"
H: Handlers=sysrq kbd leds event5
"""

        self.assertTrue(
            LaserDiagnosticUI._input_devices_include_mouse(bluetooth_combo)
        )
        self.assertFalse(
            LaserDiagnosticUI._input_devices_include_mouse(keyboard_and_hdmi_only)
        )

    def test_program_close_restores_default_cursor_before_display_closes(self) -> None:
        ui = self._new_ui()
        ui.cursor_hidden = True
        ui.xfixes_cursor = mock.Mock()

        with (
            mock.patch("pygame.mouse.set_cursor") as set_cursor,
            mock.patch("pygame.mouse.set_visible") as set_visible,
            mock.patch("pygame.event.pump") as pump,
        ):
            ui.close()

        set_cursor.assert_called_once_with(ui.default_cursor)
        set_visible.assert_called_once_with(True)
        pump.assert_called_once_with()
        ui.xfixes_cursor.close.assert_called_once_with()
        self.assertFalse(ui.cursor_hidden)


if __name__ == "__main__":
    unittest.main()
