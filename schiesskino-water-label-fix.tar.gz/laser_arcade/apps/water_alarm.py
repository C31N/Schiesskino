from __future__ import annotations

import json
import logging
import math
import random
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple

import pygame

from ..constants import WATER_ALARM_LEADERBOARD_FILE
from .arcade_common import calibrated_hit_tolerance, nearest_laser_button
from .base import BaseApp
from .cans import CanGameSounds

LOGGER = logging.getLogger(__name__)

NAVY = (0, 15, 35)
PANEL = (0, 30, 58)
PANEL_LIGHT = (0, 54, 82)
BLUE = (0, 92, 210)
CYAN = (0, 218, 245)
GREEN = (0, 235, 145)
WHITE = (225, 250, 255)
MUTED = (75, 175, 205)
YELLOW = (225, 240, 45)  # Grün bleibt stärker als Rot: laserfreundlich.
DUCK_GREEN = (0, 112, 94)
DUCK_FEATHER = (25, 116, 145)


@dataclass
class WaterTarget:
    kind: str
    x: float
    y: float
    radius: int
    points: int
    spawned_at: float
    lifetime: float
    velocity_x: float = 0.0
    velocity_y: float = 0.0
    phase: float = 0.0

    @property
    def center(self) -> Tuple[int, int]:
        return round(self.x), round(self.y)


@dataclass
class SplashParticle:
    x: float
    y: float
    velocity_x: float
    velocity_y: float
    born_at: float
    lifetime: float
    radius: int
    color: Tuple[int, int, int]


@dataclass
class FloatingText:
    text: str
    x: float
    y: float
    born_at: float
    color: Tuple[int, int, int]


@dataclass
class LeaderboardEntry:
    name: str
    score: int
    hits: int
    shots: int
    accuracy: float
    best_combo: int
    date: str

    @classmethod
    def from_dict(cls, data: dict) -> "LeaderboardEntry":
        return cls(
            name=str(data.get("name", "SPIELER"))[:8],
            score=int(data.get("score", 0)),
            hits=int(data.get("hits", 0)),
            shots=int(data.get("shots", 0)),
            accuracy=float(data.get("accuracy", 0.0)),
            best_combo=int(data.get("best_combo", data.get("bestCombo", 0))),
            date=str(data.get("date", "")),
        )


class WaterAlarmApp(BaseApp):
    """60-Sekunden-Arcadespiel der Wasserfreunde Dalum."""

    name = "Wasser-Alarm"
    GAME_DURATION = 60.0
    COUNTDOWN_DURATION = 3.35
    MAX_NAME_LENGTH = 8
    PHASE_WARMUP_END = 20.0
    PHASE_ACTION_END = 45.0
    TARGET_LIMITS = {"warmup": 3, "action": 5, "finale": 6}
    ADMIN_PIN = "2468"

    def __init__(
        self,
        screen: pygame.Surface,
        *,
        sounds: Optional[CanGameSounds] = None,
        audio_enabled: bool = True,
        leaderboard_path: Optional[Path] = WATER_ALARM_LEADERBOARD_FILE,
        random_seed: int = 20260810,
    ) -> None:
        super().__init__(screen)
        self.random = random.Random(random_seed)
        self.sounds = sounds or CanGameSounds(audio_enabled)
        self.leaderboard_path = leaderboard_path
        self.font_tiny = pygame.font.SysFont("Arial", 15)
        self.font_small = pygame.font.SysFont("Arial", 18)
        self.font = pygame.font.SysFont("Arial", 23, bold=True)
        self.font_large = pygame.font.SysFont("Arial", 36, bold=True)
        self.font_title = pygame.font.SysFont("Arial", 50, bold=True)
        self.font_countdown = pygame.font.SysFont("Arial", 128, bold=True)
        self.hit_tolerance = calibrated_hit_tolerance(screen.get_size())
        self.background, self.logo = self._load_assets()
        self._build_controls()
        self.leaderboard = self._load_leaderboard()
        self.state = "ready"
        self.state_started = time.monotonic()
        self.last_update = self.state_started
        self.play_started = 0.0
        self.deadline = 0.0
        self.player_name = ""
        self.admin_digits = ""
        self.admin_message = ""
        self.score = 0
        self.shots = 0
        self.hits = 0
        self.combo = 0
        self.best_combo = 0
        self.targets: list[WaterTarget] = []
        self.particles: list[SplashParticle] = []
        self.floating_texts: list[FloatingText] = []
        self.next_spawn_at = 0.0
        self.last_count_value: Optional[int] = None
        self.final_center = (screen.get_width() // 2, screen.get_height() // 2 + 55)
        self.final_radius = min(screen.get_width(), screen.get_height()) // 6
        self.final_hits = 0
        self.new_highscore = False
        self.current_rank: Optional[int] = None
        self.result_qualifies = False
        self.result_saved = False
        self.result_skipped = False
        self.result_date = ""
        self.phase_label_until = 0.0
        self._visual_transition_until = 0.0
        self._transition_was_active = False

    @property
    def accuracy(self) -> float:
        return 100.0 * self.hits / self.shots if self.shots else 0.0

    @property
    def multiplier(self) -> float:
        if self.combo >= 10:
            return 3.0
        if self.combo >= 5:
            return 2.0
        if self.combo >= 3:
            return 1.5
        return 1.0

    @property
    def visual_transition_active(self) -> bool:
        return time.monotonic() < self._visual_transition_until

    def _load_assets(self) -> tuple[pygame.Surface, pygame.Surface]:
        root = Path(__file__).resolve().parents[2]
        asset_dir = root / "assets" / "water_alarm"
        width, height = self.screen.get_size()
        try:
            background = pygame.image.load(str(asset_dir / "pool_background.png")).convert()
            background = pygame.transform.smoothscale(background, (width, height))
        except (FileNotFoundError, pygame.error) as exc:
            LOGGER.warning("Wasser-Alarm-Hintergrund fehlt: %s", exc)
            background = pygame.Surface((width, height))
            background.fill((0, 70, 115))
        # Etwas abdunkeln, damit der rote Laser auch vor weißen Fliesen Reserve hat.
        shade = pygame.Surface((width, height), pygame.SRCALPHA)
        shade.fill((0, 22, 45, 62))
        background.blit(shade, (0, 0))
        try:
            logo = pygame.image.load(
                str(asset_dir / "wasserfreunde_dalum_logo.png")
            ).convert_alpha()
        except (FileNotFoundError, pygame.error) as exc:
            LOGGER.warning("Wasserfreunde-Logo fehlt: %s", exc)
            logo = pygame.Surface((200, 200), pygame.SRCALPHA)
            pygame.draw.circle(logo, BLUE, (100, 100), 92, 12)
            pygame.draw.arc(logo, CYAN, pygame.Rect(38, 50, 124, 110), 0, math.pi, 12)
        return background, logo

    def _build_controls(self) -> None:
        width, height = self.screen.get_size()
        self.menu_button = pygame.Rect(width - 156, 20, 128, 42)
        self.ready_start_button = pygame.Rect(width // 2 - 244, height - 130, 488, 68)
        self.ready_menu_button = pygame.Rect(width - 156, 20, 128, 42)
        self.save_name_button = pygame.Rect(34, height - 86, 250, 58)
        self.backspace_button = pygame.Rect(296, height - 86, 118, 58)
        self.clear_button = pygame.Rect(426, height - 86, 110, 58)
        self.skip_name_button = pygame.Rect(548, height - 86, 128, 58)
        self.admin_button = pygame.Rect(952, 608, 26, 26)
        self.result_repeat_button = pygame.Rect(width // 2 - 305, height - 92, 285, 54)
        self.result_menu_button = pygame.Rect(width // 2 + 20, height - 92, 285, 54)
        self.result_card = pygame.Rect(42, 86, width - 84, height - 202)
        rows = ("ABCDEFGHIJ", "KLMNOPQRS", "TUVWXYZ012", "3456789")
        self.key_buttons: list[tuple[str, pygame.Rect]] = []
        left, top, available_width = 34, 350, 642
        gap = 6
        for row_index, row in enumerate(rows):
            key_width = (available_width - (len(row) - 1) * gap) // len(row)
            row_width = len(row) * key_width + (len(row) - 1) * gap
            row_left = left + (available_width - row_width) // 2
            for column, key in enumerate(row):
                self.key_buttons.append(
                    (key, pygame.Rect(row_left + column * (key_width + gap), top + row_index * 66, key_width, 56))
                )
        self.admin_key_buttons: list[tuple[str, pygame.Rect]] = []
        admin_rows = (("1", "2", "3"), ("4", "5", "6"), ("7", "8", "9"), ("C", "0", "ZURÜCK"))
        for row_index, row in enumerate(admin_rows):
            for column, key in enumerate(row):
                self.admin_key_buttons.append(
                    (key, pygame.Rect(312 + column * 138, 230 + row_index * 78, 124, 64))
                )
        self.admin_confirm_button = pygame.Rect(width // 2 - 210, 564, 420, 62)
        self.admin_cancel_button = pygame.Rect(width // 2 - 145, 652, 290, 50)

    def start(self, now: Optional[float] = None) -> None:
        current = now if now is not None else time.monotonic()
        self.state = "ready"
        self.state_started = current
        self.last_update = current
        self.player_name = ""
        self.admin_digits = ""
        self.admin_message = ""
        self.targets.clear()
        self.particles.clear()
        self.floating_texts.clear()
        self.result_qualifies = False
        self.result_saved = False
        self.result_skipped = False
        self.current_rank = None
        self.sounds.play("button")

    def stop(self) -> None:
        self.sounds.stop_all()
        self.targets.clear()

    def handle_key(self, event: pygame.event.Event, now: Optional[float] = None) -> str:
        if event.type != pygame.KEYDOWN:
            return "ignored"
        if self.state == "admin":
            if event.key == pygame.K_BACKSPACE:
                self.admin_digits = self.admin_digits[:-1]
                return "admin"
            if event.key in {pygame.K_RETURN, pygame.K_KP_ENTER}:
                return self._confirm_admin_pin()
            character = (getattr(event, "unicode", "") or "")
            if character.isdigit() and len(self.admin_digits) < 4:
                self.admin_digits += character
                self.sounds.play("button")
                return "admin"
            return "ignored"
        if self.state == "ready" and event.key in {
            pygame.K_RETURN,
            pygame.K_KP_ENTER,
            pygame.K_SPACE,
        }:
            return self.begin_countdown(now)
        if self.state != "name_entry":
            return "ignored"
        if event.key == pygame.K_BACKSPACE:
            self.player_name = self.player_name[:-1]
            self.sounds.play("button")
            return "name"
        if event.key in {pygame.K_RETURN, pygame.K_KP_ENTER}:
            return self._submit_name()
        character = (getattr(event, "unicode", "") or "").upper()
        if character and character in "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789":
            return self._append_name(character)
        return "ignored"

    def _append_name(self, character: str) -> str:
        if len(self.player_name) >= self.MAX_NAME_LENGTH:
            self.sounds.play("miss")
            return "full"
        self.player_name += character
        self.sounds.play("button")
        return "name"

    def begin_countdown(self, now: Optional[float] = None) -> str:
        current = now if now is not None else time.monotonic()
        self.state = "countdown"
        self.state_started = current
        self.last_count_value = None
        self._reset_round()
        self.sounds.play("button")
        return "handled"

    def _reset_round(self) -> None:
        self.score = 0
        self.shots = 0
        self.hits = 0
        self.combo = 0
        self.best_combo = 0
        self.targets.clear()
        self.particles.clear()
        self.floating_texts.clear()
        self.final_hits = 0
        self.new_highscore = False
        self.current_rank = None
        self.result_qualifies = False
        self.result_saved = False
        self.result_skipped = False
        self.result_date = ""
        self.next_spawn_at = 0.0

    def handle_shot(self, pos: Tuple[int, int], now: Optional[float] = None) -> str:
        current = now if now is not None else time.monotonic()
        if self.state == "admin":
            controls = list(self.admin_key_buttons)
            controls.extend((("confirm", self.admin_confirm_button), ("cancel", self.admin_cancel_button)))
            selected = nearest_laser_button(pos, controls, expansion=(36, 28))
            if selected == "cancel":
                self.state = "ready"
                self.state_started = current
                self.admin_digits = ""
                self.admin_message = ""
                return "handled"
            if selected == "confirm":
                return self._confirm_admin_pin()
            if selected == "C":
                self.admin_digits = ""
                self.sounds.play("button")
                return "admin"
            if selected == "ZURÜCK":
                self.admin_digits = self.admin_digits[:-1]
                self.sounds.play("button")
                return "admin"
            if isinstance(selected, str) and selected.isdigit() and len(self.admin_digits) < 4:
                self.admin_digits += selected
                self.sounds.play("button")
                return "admin"
            return "ignored"
        if self.state == "ready":
            selected = nearest_laser_button(
                pos,
                (
                    ("start", self.ready_start_button),
                    ("menu", self.ready_menu_button),
                    ("admin", self.admin_button),
                ),
                expansion=(70, 54),
            )
            if selected == "menu":
                return "menu"
            if selected == "admin":
                self.state = "admin"
                self.state_started = current
                self.admin_digits = ""
                self.admin_message = ""
                self.sounds.play("button")
                return "handled"
            if selected == "start":
                return self.begin_countdown(current)
            return "ignored"
        if self.state == "name_entry":
            controls = [(key, rect) for key, rect in self.key_buttons]
            controls.extend(
                [
                    ("save", self.save_name_button),
                    ("backspace", self.backspace_button),
                    ("clear", self.clear_button),
                    ("skip", self.skip_name_button),
                ]
            )
            selected = nearest_laser_button(pos, controls, expansion=(30, 24))
            if selected == "skip":
                return self._skip_name_entry(current)
            if selected == "save":
                return self._submit_name()
            if selected == "backspace":
                self.player_name = self.player_name[:-1]
                self.sounds.play("button")
                return "name"
            if selected == "clear":
                self.player_name = ""
                self.sounds.play("button")
                return "name"
            if isinstance(selected, str) and len(selected) == 1:
                return self._append_name(selected)
            return "ignored"
        if self.state == "result":
            awaiting_name = self.result_qualifies and not (
                self.result_saved or self.result_skipped
            )
            controls = (
                (("name", self.result_repeat_button), ("skip", self.result_menu_button))
                if awaiting_name
                else (("repeat", self.result_repeat_button), ("menu", self.result_menu_button))
            )
            selected = nearest_laser_button(
                pos,
                controls,
                expansion=(58, 46),
            )
            if selected == "name":
                self.state = "name_entry"
                self.state_started = current
                self.player_name = ""
                self.sounds.play("button")
                return "handled"
            if selected == "skip":
                return self._skip_name_entry(current)
            if selected == "menu":
                return "menu"
            if selected == "repeat":
                self.start(current)
                return "handled"
            return "ignored"
        if self.menu_button.inflate(80, 64).collidepoint(pos):
            self.sounds.play("button")
            return "menu"
        if self.state != "playing":
            return "ignored"

        self.shots += 1
        self.sounds.play("shot")
        elapsed = current - self.play_started
        if elapsed >= self.PHASE_ACTION_END and self._hit_main_pipe(pos, current):
            return "hit"
        for target in reversed(self.targets):
            hit_margin = max(34, self.hit_tolerance + 12)
            if math.dist(pos, target.center) <= target.radius + hit_margin:
                self.targets.remove(target)
                if target.kind == "logo":
                    self.score = max(0, self.score - 500)
                    self.combo = 0
                    self._add_float("−500  SCHUTZZIEL!", target.x, target.y, MUTED, current)
                    self._add_splash(target.x, target.y, current, negative=True)
                    self.sounds.play("miss")
                    self._visual_transition_until = time.monotonic() + 0.28
                    return "penalty"
                self._score_hit(target.points, target.x, target.y, current)
                return "hit"
        self.combo = 0
        self._add_float("DANEBEN", pos[0], pos[1], MUTED, current)
        self.sounds.play("miss")
        return "miss"

    def _submit_name(self) -> str:
        if not self.player_name:
            self.sounds.play("miss")
            return "name_required"
        entry = LeaderboardEntry(
            self.player_name,
            self.score,
            self.hits,
            self.shots,
            round(self.accuracy, 1),
            self.best_combo,
            self.result_date,
        )
        self.leaderboard.append(entry)
        self._sort_leaderboard()
        self.leaderboard = self.leaderboard[:10]
        self.current_rank = next(
            (index + 1 for index, item in enumerate(self.leaderboard) if item is entry),
            None,
        )
        self.result_saved = self.current_rank is not None
        self.state = "result"
        self._save_leaderboard()
        self.sounds.play("finish")
        return "saved"

    def _skip_name_entry(self, now: float) -> str:
        self.result_skipped = True
        self.result_saved = False
        self.current_rank = None
        self.new_highscore = False
        self.player_name = ""
        self.state = "result"
        self.state_started = now
        self.sounds.play("button")
        return "skipped"

    def _confirm_admin_pin(self) -> str:
        if self.admin_digits != self.ADMIN_PIN:
            self.admin_digits = ""
            self.admin_message = "PIN FALSCH"
            self.sounds.play("miss")
            return "admin_denied"
        self.leaderboard.clear()
        self._save_leaderboard()
        self.admin_digits = ""
        self.admin_message = "BESTENLISTE GELÖSCHT"
        self.state = "ready"
        self.sounds.play("finish")
        LOGGER.info("Wasser-Alarm-Bestenliste über Admin-PIN zurückgesetzt")
        return "admin_reset"

    def _hit_main_pipe(self, pos: Tuple[int, int], now: float) -> bool:
        distance = math.dist(pos, self.final_center)
        if distance > self.final_radius + max(34, self.hit_tolerance + 12):
            return False
        ratio = distance / max(1, self.final_radius)
        if ratio <= 0.18:
            points = 1000
        elif ratio <= 0.42:
            points = 500
        elif ratio <= 0.70:
            points = 250
        else:
            points = 100
        self.final_hits += 1
        self._score_hit(points, self.final_center[0], self.final_center[1], now)
        margin = self.final_radius + 42
        self.final_center = (
            self.random.randint(margin, self.screen.get_width() - margin),
            self.random.randint(170 + margin, self.screen.get_height() - margin),
        )
        return True

    def _score_hit(self, base_points: int, x: float, y: float, now: float) -> None:
        self.hits += 1
        self.combo += 1
        self.best_combo = max(self.best_combo, self.combo)
        gained = round(base_points * self.multiplier)
        self.score += gained
        suffix = f"  ×{self.multiplier:g}" if self.multiplier > 1 else ""
        self._add_float(f"+{gained}{suffix}", x, y, GREEN, now)
        self._add_splash(x, y, now)
        self.sounds.play("wave" if self.combo in {3, 5, 10} else "metal1")

    def update(self, now: Optional[float] = None) -> None:
        current = now if now is not None else time.monotonic()
        dt = max(0.0, min(0.08, current - self.last_update))
        self.last_update = current
        if self.state == "countdown":
            elapsed = current - self.state_started
            count = max(0, 3 - int(elapsed))
            if count != self.last_count_value and count > 0:
                self.sounds.play("count")
                self.last_count_value = count
            if elapsed >= self.COUNTDOWN_DURATION:
                self.state = "playing"
                self.state_started = current
                self.play_started = current
                self.deadline = current + self.GAME_DURATION
                self.next_spawn_at = current
                self.phase_label_until = current + 2.0
                self.sounds.play("go")
            return
        if self.state != "playing":
            return
        elapsed = current - self.play_started
        if elapsed >= self.GAME_DURATION:
            self._finish(current)
            return
        phase = self.phase
        self._update_targets(current, dt)
        limit = self.TARGET_LIMITS[phase]
        if current >= self.next_spawn_at and len(self.targets) < limit:
            self._spawn_for_phase(phase, current)
            interval = {
                "warmup": (0.75, 1.15),
                "action": (0.42, 0.78),
                "finale": (0.30, 0.58),
            }[phase]
            self.next_spawn_at = current + self.random.uniform(*interval)
        self.particles = [p for p in self.particles if current - p.born_at < p.lifetime]
        for particle in self.particles:
            particle.x += particle.velocity_x * dt
            particle.y += particle.velocity_y * dt
            particle.velocity_y += 150 * dt
        self.floating_texts = [f for f in self.floating_texts if current - f.born_at < 1.2]

    @property
    def phase(self) -> str:
        if self.state != "playing":
            return "warmup"
        elapsed = time.monotonic() - self.play_started
        # Tests und die Spielschleife können explizite Zeitwerte verwenden.
        if self.last_update >= self.play_started:
            elapsed = self.last_update - self.play_started
        if elapsed < self.PHASE_WARMUP_END:
            return "warmup"
        if elapsed < self.PHASE_ACTION_END:
            return "action"
        return "finale"

    @property
    def remaining(self) -> float:
        if self.state != "playing":
            return self.GAME_DURATION
        return max(0.0, self.deadline - self.last_update)

    def _update_targets(self, now: float, dt: float) -> None:
        survivors: list[WaterTarget] = []
        width, height = self.screen.get_size()
        for target in self.targets:
            if now - target.spawned_at >= target.lifetime:
                if target.kind == "logo":
                    self._visual_transition_until = time.monotonic() + 0.28
                continue
            target.x += target.velocity_x * dt
            target.y += target.velocity_y * dt
            if target.x - target.radius < 10 or target.x + target.radius > width - 10:
                target.velocity_x *= -1
                target.x = max(target.radius + 10, min(width - target.radius - 10, target.x))
            if target.y - target.radius < 145 or target.y + target.radius > height - 12:
                target.velocity_y *= -1
                target.y = max(145 + target.radius, min(height - target.radius - 12, target.y))
            survivors.append(target)
        self.targets = survivors

    def _spawn_for_phase(self, phase: str, now: float) -> None:
        if phase == "warmup":
            kind = self.random.choices(("leak_big", "leak_medium", "leak_small"), (5, 3, 2))[0]
        elif phase == "action":
            kind = self.random.choices(
                ("ball", "duck", "ring", "gold", "logo"),
                (34, 28, 22, 6, 10),
            )[0]
        else:
            kind = self.random.choices(("ball", "duck", "ring", "gold"), (33, 31, 26, 10))[0]
        self._spawn_target(kind, now)

    def _spawn_target(self, kind: str, now: float) -> WaterTarget:
        specs = {
            "leak_big": (64, 100, 4.2, 0),
            "leak_medium": (48, 150, 3.6, 0),
            "leak_small": (34, 250, 3.0, 0),
            "ball": (48, 200, 5.8, 115),
            "duck": (50, 300, 7.5, 92),
            "ring": (46, 500, 2.8, 28),
            "gold": (38, 1000, 2.2, 55),
            "logo": (52, -500, 2.5, 0),
        }
        radius, points, lifetime, speed = specs[kind]
        width, height = self.screen.get_size()
        x, y = self._find_spawn_position(kind, radius, width, height)
        direction = -1 if self.random.random() < 0.5 else 1
        velocity_x = direction * speed if kind in {"ball", "duck"} else 0
        velocity_y = self.random.uniform(-35, 35) if kind == "ball" else 0
        target = WaterTarget(
            kind, x, y, radius, points, now, lifetime, velocity_x, velocity_y,
            self.random.random() * math.tau,
        )
        self.targets.append(target)
        if kind == "logo":
            # Rote Flächen des offiziellen Logos dürfen beim Einblenden nicht
            # als Laserimpuls interpretiert werden.
            self._visual_transition_until = time.monotonic() + 0.32
        return target

    def _find_spawn_position(
        self, kind: str, radius: int, width: int, height: int
    ) -> Tuple[int, int]:
        candidate = (width // 2, height // 2)
        for _ in range(24):
            x = self.random.randint(radius + 42, width - radius - 42)
            if kind == "duck":
                # Zwei klar erkennbare Schwimmbahnen, weit genug vom unteren
                # Bildrand für Punktzahl, Welle und vollständige Trefferfläche.
                y = self.random.choice((570, 646))
            elif kind in {"ring", "gold"}:
                y = self.random.choice((535, 635))
            elif kind == "ball":
                y = self.random.randint(190 + radius, 485 - radius)
            elif kind == "logo":
                y = self.random.randint(220 + radius, 525 - radius)
            else:
                y = self.random.randint(175 + radius, height - radius - 72)
            candidate = (x, y)
            if all(
                math.dist(candidate, existing.center)
                >= radius + existing.radius + 54
                for existing in self.targets
            ):
                return candidate
        return candidate

    def _finish(self, now: float) -> None:
        self.state = "result"
        self.state_started = now
        self.player_name = ""
        self.result_date = datetime.now().astimezone().isoformat(timespec="seconds")
        candidate = LeaderboardEntry(
            "",
            self.score,
            self.hits,
            self.shots,
            round(self.accuracy, 1),
            self.best_combo,
            self.result_date,
        )
        ranked = [*self.leaderboard, candidate]
        ranked.sort(key=lambda item: (-item.score, -item.accuracy, -item.best_combo, item.date))
        prospective_rank = ranked.index(candidate) + 1
        self.result_qualifies = prospective_rank <= 10
        self.current_rank = prospective_rank if self.result_qualifies else None
        self.new_highscore = self.result_qualifies and prospective_rank == 1
        self.result_saved = False
        self.result_skipped = False
        self.targets.clear()
        self.sounds.play("finish")
        LOGGER.info(
            "Wasser-Alarm beendet: %s Punkte, %s/%s Treffer, %.1f%%, Combo %s, Top-10=%s, Rang=%s",
            self.score, self.hits, self.shots, self.accuracy, self.best_combo,
            self.result_qualifies, self.current_rank,
        )

    def _sort_leaderboard(self) -> None:
        self.leaderboard.sort(key=lambda item: (-item.score, -item.accuracy, -item.best_combo, item.date))

    def _load_leaderboard(self) -> list[LeaderboardEntry]:
        if self.leaderboard_path is None or not self.leaderboard_path.exists():
            return []
        try:
            data = json.loads(self.leaderboard_path.read_text(encoding="utf-8"))
            entries = [LeaderboardEntry.from_dict(item) for item in data if isinstance(item, dict)]
            entries.sort(key=lambda item: (-item.score, -item.accuracy, -item.best_combo, item.date))
            return entries[:10]
        except (OSError, ValueError, TypeError) as exc:
            LOGGER.warning("Wasser-Alarm-Bestenliste konnte nicht geladen werden: %s", exc)
            return []

    def _save_leaderboard(self) -> None:
        if self.leaderboard_path is None:
            return
        try:
            self.leaderboard_path.parent.mkdir(parents=True, exist_ok=True)
            temp_path = self.leaderboard_path.with_suffix(".tmp")
            temp_path.write_text(
                json.dumps([asdict(item) for item in self.leaderboard], ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            temp_path.replace(self.leaderboard_path)
        except OSError as exc:
            LOGGER.warning("Wasser-Alarm-Bestenliste konnte nicht gespeichert werden: %s", exc)

    def _add_splash(self, x: float, y: float, now: float, negative: bool = False) -> None:
        colors = (MUTED, BLUE) if negative else (CYAN, GREEN, WHITE)
        for _ in range(18):
            angle = self.random.uniform(0, math.tau)
            speed = self.random.uniform(55, 220)
            self.particles.append(
                SplashParticle(
                    x, y, math.cos(angle) * speed, math.sin(angle) * speed,
                    now, self.random.uniform(0.45, 0.85), self.random.randint(2, 6),
                    self.random.choice(colors),
                )
            )

    def _add_float(self, text: str, x: float, y: float, color: Tuple[int, int, int], now: float) -> None:
        self.floating_texts.append(FloatingText(text, x, y, now, color))

    def draw(self, now: Optional[float] = None) -> None:
        current = now if now is not None else time.monotonic()
        if self.state == "ready":
            self._draw_ready_screen()
        elif self.state == "name_entry":
            self._draw_name_entry_screen()
        elif self.state == "admin":
            self._draw_admin_screen()
        elif self.state == "countdown":
            self._draw_scene(current)
            self._draw_countdown(current)
        elif self.state == "playing":
            self._draw_scene(current)
            self._draw_playing(current)
        else:
            self._draw_result()

    def _draw_scene(self, now: float) -> None:
        self.screen.blit(self.background, (0, 0))
        # Dezente rein blau/cyanfarbene Wasserbewegung.
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        for index in range(9):
            x = int((index * 147 + now * (12 + index)) % (self.screen.get_width() + 160) - 80)
            y = self.screen.get_height() - 38 - (index % 3) * 34
            pygame.draw.ellipse(overlay, (0, 205, 245, 28), pygame.Rect(x, y, 150, 20), 2)
        self.screen.blit(overlay, (0, 0))

    def _draw_ready_screen(self) -> None:
        self._draw_scene(time.monotonic())
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 12, 30, 170))
        self.screen.blit(veil, (0, 0))
        logo = pygame.transform.smoothscale(self.logo, (108, 108))
        self.screen.blit(logo, logo.get_rect(midtop=(82, 26)))
        title = self.font_title.render("WASSERFREUNDE DALUM", True, WHITE)
        self.screen.blit(title, title.get_rect(midtop=(480, 34)))
        subtitle = self.font_large.render("WASSER-ALARM", True, CYAN)
        self.screen.blit(subtitle, subtitle.get_rect(midtop=(480, 96)))

        info = pygame.Rect(34, 218, 642, 384)
        self._panel(info, CYAN)
        heading = self.font_large.render("60 SEKUNDEN WASSER-ACTION", True, WHITE)
        self.screen.blit(heading, heading.get_rect(midtop=(info.centerx, info.top + 28)))
        lines = (
            ("1", "LECKS SCHLIEßEN", "Große, ruhige Ziele zum Aufwärmen"),
            ("2", "WASSER-CHAOS", "Schwimmende Enten, Bälle und Bonusringe"),
            ("3", "DAS GROßE LECK", "Vier Trefferzonen im 15-Sekunden-Finale"),
        )
        for index, (number, phase, explanation) in enumerate(lines):
            y = info.top + 102 + index * 76
            pygame.draw.circle(self.screen, NAVY, (info.left + 48, y + 16), 25)
            pygame.draw.circle(self.screen, GREEN, (info.left + 48, y + 16), 25, 2)
            number_surface = self.font.render(number, True, GREEN)
            self.screen.blit(number_surface, number_surface.get_rect(center=(info.left + 48, y + 16)))
            phase_surface = self.font.render(phase, True, CYAN)
            explanation_surface = self.font_small.render(explanation, True, WHITE)
            self.screen.blit(phase_surface, (info.left + 88, y - 2))
            self.screen.blit(explanation_surface, (info.left + 88, y + 29))
        hint = self.font_small.render("NAME NUR BEI EINEM TOP-10-ERGEBNIS · FREIWILLIG", True, MUTED)
        self.screen.blit(hint, hint.get_rect(midbottom=(info.centerx, info.bottom - 20)))

        leaderboard_rect = pygame.Rect(698, 120, 292, 482)
        self._draw_leaderboard(leaderboard_rect)
        self._button(self.ready_start_button, "SPIEL STARTEN", self.font_large, GREEN)
        self._button(self.ready_menu_button, "MENÜ", self.font_small, CYAN, aim=False)
        # Bewusst unauffälliger, PIN-geschützter Admin-Einstieg.
        pygame.draw.rect(self.screen, BLUE, self.admin_button, 1, border_radius=5)
        for offset in (-6, 0, 6):
            pygame.draw.circle(self.screen, MUTED, (self.admin_button.centerx + offset, self.admin_button.centery), 2)

    def _draw_name_entry_screen(self) -> None:
        self._draw_scene(time.monotonic())
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 12, 30, 180))
        self.screen.blit(veil, (0, 0))
        logo = pygame.transform.smoothscale(self.logo, (72, 72))
        self.screen.blit(logo, (24, 20))
        rank = self.current_rank or 10
        title = self.font_large.render(f"TOP 10 · VORAUSSICHTLICH RANG {rank}", True, GREEN)
        self.screen.blit(title, title.get_rect(midtop=(530, 26)))
        score = self.font.render(f"{self.score:,} PUNKTE".replace(",", "."), True, WHITE)
        self.screen.blit(score, score.get_rect(midtop=(530, 76)))

        entry_card = pygame.Rect(34, 126, 642, 204)
        self._panel(entry_card, CYAN)
        label = self.font_small.render("NAME FREIWILLIG EINTRAGEN · MAXIMAL 8 ZEICHEN", True, MUTED)
        self.screen.blit(label, (entry_card.left + 22, entry_card.top + 16))
        shown = self.player_name or "_ _ _ _ _ _ _ _"
        name_surface = self.font_large.render(shown, True, WHITE if self.player_name else MUTED)
        name_box = pygame.Rect(entry_card.left + 22, entry_card.top + 52, entry_card.width - 44, 70)
        pygame.draw.rect(self.screen, NAVY, name_box, border_radius=10)
        pygame.draw.rect(self.screen, GREEN, name_box, 2, border_radius=10)
        self.screen.blit(name_surface, name_surface.get_rect(center=name_box.center))
        hint = self.font_small.render("KEIN ZEITLIMIT · EINTRAGEN ODER ÜBERSPRINGEN", True, GREEN)
        self.screen.blit(hint, hint.get_rect(midtop=(entry_card.centerx, entry_card.top + 145)))

        self._draw_leaderboard(pygame.Rect(698, 126, 292, 526))
        for key, rect in self.key_buttons:
            self._button(rect, key, self.font, CYAN, aim=False)
        self._button(self.save_name_button, "EINTRAGEN", self.font, GREEN)
        self._button(self.backspace_button, "ZURÜCK", self.font_small, CYAN, aim=False)
        self._button(self.clear_button, "LÖSCHEN", self.font_small, MUTED, aim=False)
        self._button(self.skip_name_button, "ÜBERSPRINGEN", self.font_tiny, CYAN, aim=False)

    def _draw_leaderboard(self, rect: pygame.Rect) -> None:
        self._panel(rect, BLUE)
        heading = self.font.render("TOP 10", True, CYAN)
        self.screen.blit(heading, heading.get_rect(midtop=(rect.centerx, rect.top + 16)))
        if not self.leaderboard:
            empty = self.font_small.render("NOCH KEIN ERGEBNIS", True, MUTED)
            self.screen.blit(empty, empty.get_rect(center=(rect.centerx, rect.centery)))
        line_gap = min(41, max(31, (rect.height - 76) // 10))
        for index, entry in enumerate(self.leaderboard[:10], start=1):
            y = rect.top + 60 + (index - 1) * line_gap
            rank = self.font_small.render(f"{index:>2}", True, GREEN if index <= 3 else MUTED)
            name = self.font_small.render(entry.name, True, WHITE)
            score = self.font_small.render(f"{entry.score:,}".replace(",", "."), True, CYAN)
            self.screen.blit(rank, (rect.left + 14, y))
            self.screen.blit(name, (rect.left + 47, y))
            self.screen.blit(score, score.get_rect(topright=(rect.right - 14, y)))

    def _draw_admin_screen(self) -> None:
        self._draw_scene(time.monotonic())
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 10, 28, 190))
        self.screen.blit(veil, (0, 0))
        card = pygame.Rect(215, 74, 594, 642)
        self._panel(card, CYAN)
        title = self.font_large.render("BESTENLISTE VERWALTEN", True, WHITE)
        self.screen.blit(title, title.get_rect(midtop=(card.centerx, card.top + 28)))
        subtitle = self.font_small.render("ADMIN-PIN EINGEBEN", True, MUTED)
        self.screen.blit(subtitle, subtitle.get_rect(midtop=(card.centerx, card.top + 82)))
        pin_text = "● " * len(self.admin_digits) + "○ " * (4 - len(self.admin_digits))
        pin = self.font_large.render(pin_text.strip(), True, GREEN)
        self.screen.blit(pin, pin.get_rect(midtop=(card.centerx, card.top + 116)))
        if self.admin_message:
            message = self.font_small.render(self.admin_message, True, MUTED)
            self.screen.blit(message, message.get_rect(midtop=(card.centerx, card.top + 163)))
        for key, rect in self.admin_key_buttons:
            self._button(rect, key, self.font_small if len(key) > 1 else self.font, CYAN, aim=False)
        self._button(self.admin_confirm_button, "BESTENLISTE ZURÜCKSETZEN", self.font, GREEN)
        self._button(self.admin_cancel_button, "ABBRECHEN", self.font_small, CYAN)

    def _draw_playing(self, now: float) -> None:
        width = self.screen.get_width()
        hud = pygame.Rect(14, 12, width - 28, 92)
        self._panel(hud, CYAN)
        phase_label = {"warmup": "LECKS SCHLIEßEN", "action": "WASSER-CHAOS", "finale": "DAS GROßE LECK"}[self.phase]
        values = (
            ("SPIELER", 105),
            (f"PUNKTE {self.score:,}".replace(",", "."), 315),
            (f"ZEIT {math.ceil(self.remaining):02d}", 515),
            (f"COMBO ×{self.multiplier:g}", 705),
        )
        for text, x in values:
            surface = self.font.render(text, True, GREEN if "COMBO" in text else WHITE)
            self.screen.blit(surface, surface.get_rect(center=(x, hud.top + 34)))
        phase = self.font_small.render(phase_label, True, CYAN)
        self.screen.blit(phase, phase.get_rect(center=(hud.centerx - 28, hud.bottom - 20)))
        self._button(self.menu_button, "MENÜ", self.font_small, CYAN, aim=False)

        for target in self.targets:
            self._draw_target(target, now)
        if self.phase == "finale":
            self._draw_main_pipe(now)
        self._draw_effects(now)

        elapsed = now - self.play_started
        if 45.0 <= elapsed < 46.5:
            self._draw_phase_banner("ACHTUNG!", "DAS HAUPTROHR IST GEBROCHEN!")
        elif elapsed < 1.4 or 20.0 <= elapsed < 21.5:
            subtitle = "GROßE ZIELE ZUERST" if elapsed < 20.0 else "SCHNELLER · KLEINER · COMBOS"
            self._draw_phase_banner(phase_label, subtitle)
        if self.remaining <= 3.0:
            number = str(max(1, math.ceil(self.remaining)))
            self._draw_phase_banner(number, "ENDE!")

    def _draw_target(self, target: WaterTarget, now: float) -> None:
        x, y = target.center
        r = target.radius
        pulse = 1.0 + 0.055 * math.sin(now * 7 + target.phase)
        r = round(r * pulse)
        # Jede Figur liegt auf einer dunklen Projektionsfläche. Dadurch besitzt
        # der rote Laserpuls unabhängig von Fliesen, Wasserreflexen oder Farbe
        # des Motivs immer genügend Rot- und Helligkeitsreserve.
        pad_radius = r + 11
        if target.kind == "duck":
            bob = round(2 * math.sin(now * 4.2 + target.phase))
            y += bob
            # Die dunkle Trefferreserve liegt wie ein natürlicher Schatten im
            # Wasser und nicht mehr als runde Scheibe hinter der Ente.
            duck_pad = pygame.Rect(x-r-14, y-r//2-14, 2*r+28, r+48)
            pygame.draw.ellipse(self.screen, NAVY, duck_pad)
            pygame.draw.ellipse(self.screen, CYAN, duck_pad, 2)
        else:
            pygame.draw.circle(self.screen, NAVY, (x, y), pad_radius)
            pygame.draw.circle(self.screen, CYAN, (x, y), pad_radius, 3)
        if target.kind.startswith("leak"):
            for angle in range(0, 360, 45):
                endpoint = (
                    x + round(math.cos(math.radians(angle)) * (r - 3)),
                    y + round(math.sin(math.radians(angle)) * (r - 3)),
                )
                pygame.draw.line(self.screen, BLUE, (x, y), endpoint, 4)
            pygame.draw.circle(self.screen, PANEL, (x, y), max(14, r // 2))
            pygame.draw.circle(self.screen, CYAN, (x, y), max(14, r // 2), 3)
        elif target.kind == "ball":
            pygame.draw.circle(self.screen, PANEL, (x, y), r - 3)
            pygame.draw.circle(self.screen, WHITE, (x, y), r - 3, 4)
            pygame.draw.arc(self.screen, BLUE, pygame.Rect(x-r, y-r, 2*r, 2*r), -0.3, 2.2, 9)
            pygame.draw.arc(self.screen, CYAN, pygame.Rect(x-r, y-r, 2*r, 2*r), 2.8, 5.7, 9)
        elif target.kind == "duck":
            # Ruhige, realistischere Stockenten-Silhouette. Alle Gefiederfarben
            # bleiben laserneutral; die große dunkle Körperfläche ist zugleich
            # die zuverlässige Trefferzone.
            facing = 1 if target.velocity_x >= 0 else -1
            front_x = x + facing * (r // 2)
            back_x = x - facing * (r - 5)
            wake_y = y + r // 3 + 8
            pygame.draw.lines(
                self.screen,
                CYAN,
                False,
                ((back_x-facing*28, wake_y), (back_x-facing*12, wake_y-4), (back_x, wake_y)),
                3,
            )
            pygame.draw.arc(self.screen, BLUE, pygame.Rect(x-r-20, wake_y-5, 2*r+40, 22), 0, math.pi, 3)

            tail = (
                (back_x, y-9),
                (back_x-facing*24, y-22),
                (back_x-facing*17, y+3),
            )
            pygame.draw.polygon(self.screen, DUCK_FEATHER, tail)
            pygame.draw.polygon(self.screen, WHITE, tail, 2)

            body = pygame.Rect(x-r+5, y-r//3, 2*r-10, r+8)
            pygame.draw.ellipse(self.screen, PANEL_LIGHT, body)
            pygame.draw.ellipse(self.screen, WHITE, body, 3)
            chest_rect = pygame.Rect(front_x-r//3, y-r//4, 2*r//3, r)
            pygame.draw.ellipse(self.screen, DUCK_GREEN, chest_rect)

            wing = pygame.Rect(x-r//2, y-r//4, r, r//2+12)
            pygame.draw.ellipse(self.screen, DUCK_FEATHER, wing)
            pygame.draw.ellipse(self.screen, CYAN, wing, 2)
            for offset in (-9, 0, 9):
                pygame.draw.line(
                    self.screen,
                    MUTED,
                    (x-r//3, y+offset//3),
                    (x+r//3, y+r//6+offset//3),
                    2,
                )

            neck = (front_x, y-r//3)
            head = (front_x + facing * 3, y-r//2)
            pygame.draw.circle(self.screen, WHITE, neck, r//3+3)
            pygame.draw.circle(self.screen, DUCK_GREEN, head, r//3)
            pygame.draw.circle(self.screen, CYAN, head, r//3, 2)
            eye = (head[0] + facing * 6, head[1] - 5)
            pygame.draw.circle(self.screen, WHITE, eye, 4)
            pygame.draw.circle(self.screen, NAVY, eye, 2)
            beak_base = head[0] + facing * (r//3-2)
            beak = (
                (beak_base, head[1]-5),
                (beak_base + facing*20, head[1]+1),
                (beak_base, head[1]+8),
            )
            pygame.draw.polygon(self.screen, YELLOW, beak)
            pygame.draw.polygon(self.screen, WHITE, beak, 2)

            # Die Wasserlinie liegt vor dem Bauch: Die Ente wirkt schwimmend,
            # während das dezente Visier die Mitte sicher auffindbar hält.
            pygame.draw.line(self.screen, CYAN, (x-r-8, wake_y), (x+r+8, wake_y), 3)
        elif target.kind in {"ring", "gold"}:
            color = YELLOW if target.kind == "gold" else CYAN
            pygame.draw.circle(self.screen, PANEL, (x, y), r - 2)
            pygame.draw.circle(self.screen, color, (x, y), r, max(9, r // 3))
            pygame.draw.circle(self.screen, WHITE, (x, y), r + 3, 2)
        elif target.kind == "logo":
            logo = pygame.transform.smoothscale(self.logo, (2*r - 22, 2*r - 22))
            self.screen.blit(logo, logo.get_rect(center=(x, y)))
            warning = self.font_tiny.render("NICHT SCHIEßEN", True, WHITE)
            self.screen.blit(warning, warning.get_rect(midbottom=(x, y-r-14)))
        if target.kind != "logo":
            self._draw_hit_core((x, y))

    def _draw_hit_core(self, center: Tuple[int, int]) -> None:
        pygame.draw.circle(self.screen, NAVY, center, 13)
        pygame.draw.circle(self.screen, GREEN, center, 13, 3)
        pygame.draw.circle(self.screen, CYAN, center, 3)

    def _draw_main_pipe(self, now: float) -> None:
        center, radius = self.final_center, self.final_radius
        pulse = round(5 * math.sin(now * 6))
        pygame.draw.circle(self.screen, PANEL, center, radius + 12 + pulse)
        pygame.draw.circle(self.screen, WHITE, center, radius + 12 + pulse, 5)
        rings = ((1.0, 100, BLUE), (0.70, 250, CYAN), (0.42, 500, GREEN), (0.18, 1000, YELLOW))
        for factor, points, color in rings:
            ring_radius = max(9, round(radius * factor))
            pygame.draw.circle(self.screen, color, center, ring_radius, 7)
            text = self.font_tiny.render(str(points), True, WHITE)
            self.screen.blit(text, text.get_rect(center=(center[0], center[1] - ring_radius + 12)))
        self._draw_hit_core(center)
        pipe_label = self.font_small.render("HAUPTROHR", True, WHITE)
        self.screen.blit(pipe_label, pipe_label.get_rect(midbottom=(center[0], center[1]-radius-16)))

    def _draw_effects(self, now: float) -> None:
        for particle in self.particles:
            life = max(0.0, 1.0 - (now - particle.born_at) / particle.lifetime)
            color = tuple(round(component * life) for component in particle.color)
            pygame.draw.circle(self.screen, color, (round(particle.x), round(particle.y)), max(1, round(particle.radius * life)))
        for floating in self.floating_texts:
            age = now - floating.born_at
            y = floating.y - age * 52
            surface = self.font.render(floating.text, True, floating.color)
            self.screen.blit(surface, surface.get_rect(center=(round(floating.x), round(y))))

    def _draw_countdown(self, now: float) -> None:
        elapsed = now - self.state_started
        label = "LOS!" if elapsed >= 3.0 else str(max(1, 3 - int(elapsed)))
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 14, 35, 175))
        self.screen.blit(veil, (0, 0))
        player = self.font_large.render("WASSER-ALARM", True, WHITE)
        self.screen.blit(player, player.get_rect(midtop=(self.screen.get_width() // 2, 150)))
        text = self.font_countdown.render(label, True, GREEN if label == "LOS!" else CYAN)
        self.screen.blit(text, text.get_rect(center=self.screen.get_rect().center))

    def _draw_phase_banner(self, title: str, subtitle: str) -> None:
        # Kompakter Hinweis direkt unter dem HUD; die Ziele und die gesamte
        # eigentliche Spielfläche bleiben jederzeit sichtbar und beschießbar.
        banner = pygame.Rect(176, 112, self.screen.get_width() - 352, 54)
        overlay = pygame.Surface(banner.size, pygame.SRCALPHA)
        overlay.fill((0, 22, 52, 232))
        self.screen.blit(overlay, banner)
        pygame.draw.rect(self.screen, CYAN, banner, 2, border_radius=12)
        message = self.font.render(f"{title}  ·  {subtitle}", True, YELLOW if title.isdigit() else WHITE)
        self.screen.blit(message, message.get_rect(center=banner.center))

    def _draw_result(self) -> None:
        self._draw_scene(time.monotonic())
        veil = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        veil.fill((0, 10, 28, 185))
        self.screen.blit(veil, (0, 0))
        self._panel(self.result_card, GREEN if self.new_highscore else CYAN)
        logo = pygame.transform.smoothscale(self.logo, (92, 92))
        self.screen.blit(logo, (self.result_card.left + 28, self.result_card.top + 20))
        awaiting_name = self.result_qualifies and not (
            self.result_saved or self.result_skipped
        )
        if self.new_highscore:
            title_text = "NEUER ZELTLAGER-REKORD!"
        elif awaiting_name:
            title_text = "TOP-10-ERGEBNIS!"
        else:
            title_text = "RUNDE BEENDET"
        title = self.font_large.render(title_text, True, YELLOW if self.new_highscore else CYAN)
        self.screen.blit(title, title.get_rect(midtop=(self.result_card.centerx + 42, self.result_card.top + 26)))
        if awaiting_name:
            status_text = f"RANG {self.current_rank} MÖGLICH"
        elif self.result_saved:
            status_text = f"{self.player_name} · RANG {self.current_rank} GESPEICHERT"
        elif self.result_skipped:
            status_text = "OHNE NAMEN ÜBERSPRUNGEN"
        else:
            status_text = "DANKE FÜRS MITSPIELEN"
        status = self.font.render(status_text, True, WHITE)
        self.screen.blit(status, status.get_rect(midtop=(self.result_card.centerx + 42, self.result_card.top + 78)))

        metrics = (
            ("PUNKTE", f"{self.score:,}".replace(",", ".")),
            ("TREFFER", str(self.hits)),
            ("SCHÜSSE", str(self.shots)),
            ("GENAUIGKEIT", f"{self.accuracy:.0f} %"),
            ("BESTE COMBO", str(self.best_combo)),
        )
        left = self.result_card.left + 34
        metric_y = self.result_card.top + 145
        metric_width = (self.result_card.width - 68) // len(metrics)
        for index, (label, value) in enumerate(metrics):
            center_x = left + index * metric_width + metric_width // 2
            small = self.font_tiny.render(label, True, MUTED)
            large = self.font_large.render(value, True, GREEN)
            self.screen.blit(small, small.get_rect(center=(center_x, metric_y)))
            self.screen.blit(large, large.get_rect(center=(center_x, metric_y + 40)))

        ranking = pygame.Rect(self.result_card.left + 34, self.result_card.top + 228, self.result_card.width - 68, 225)
        pygame.draw.rect(self.screen, NAVY, ranking, border_radius=12)
        heading = self.font.render("AKTUELLE TOP 10", True, CYAN)
        self.screen.blit(heading, heading.get_rect(midtop=(ranking.centerx, ranking.top + 12)))
        for index, entry in enumerate(self.leaderboard[:10]):
            column = index // 5
            row = index % 5
            x = ranking.left + 28 + column * (ranking.width // 2)
            y = ranking.top + 55 + row * 31
            color = GREEN if self.result_saved and entry.name == self.player_name and entry.score == self.score else WHITE
            score = f"{entry.score:,}".replace(",", ".")
            line = self.font_small.render(
                f"{index+1:>2}. {entry.name:<8}  {score:>7}  {entry.accuracy:.0f}%", True, color
            )
            self.screen.blit(line, (x, y))
        if awaiting_name:
            self._button(self.result_repeat_button, "NAMEN EINTRAGEN", self.font, GREEN)
            self._button(self.result_menu_button, "ÜBERSPRINGEN", self.font, CYAN)
        else:
            self._button(self.result_repeat_button, "NOCH EINMAL", self.font, GREEN)
            self._button(self.result_menu_button, "MENÜ", self.font, CYAN)

    def _panel(self, rect: pygame.Rect, border: Tuple[int, int, int]) -> None:
        pygame.draw.rect(self.screen, PANEL, rect, border_radius=14)
        pygame.draw.rect(self.screen, border, rect, 3, border_radius=14)

    def _button(
        self,
        rect: pygame.Rect,
        label: str,
        font: pygame.font.Font,
        color: Tuple[int, int, int],
        *,
        aim: bool = True,
    ) -> None:
        pygame.draw.rect(self.screen, PANEL_LIGHT, rect, border_radius=9)
        pygame.draw.rect(self.screen, color, rect, 2, border_radius=9)
        if aim:
            pygame.draw.circle(self.screen, color, (rect.left + 15, rect.centery), 6, 2)
        text = font.render(label, True, color)
        self.screen.blit(text, text.get_rect(center=(rect.centerx + (7 if aim else 0), rect.centery)))
