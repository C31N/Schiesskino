from __future__ import annotations

import os
import tempfile
import time
import unittest
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

import pygame
import numpy as np
import cv2

from laser_arcade.apps.water_alarm import LeaderboardEntry, WaterAlarmApp
from laser_arcade.shot_detector import DetectionConfig, PulseShotDetector


class WaterAlarmTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        pygame.init()
        pygame.display.set_mode((1024, 768))

    @classmethod
    def tearDownClass(cls) -> None:
        pygame.quit()

    def setUp(self) -> None:
        self.screen = pygame.Surface((1024, 768))

    def _game(self, path: Path | None = None) -> WaterAlarmApp:
        return WaterAlarmApp(
            self.screen,
            audio_enabled=False,
            leaderboard_path=path,
            random_seed=7,
        )

    def test_round_starts_without_name_entry(self) -> None:
        game = self._game()
        game.start(100.0)
        self.assertEqual(game.state, "ready")
        self.assertEqual(game.player_name, "")
        self.assertEqual(game.handle_shot(game.ready_start_button.center, 101.0), "handled")
        self.assertEqual(game.state, "countdown")
        game.update(105.0)
        self.assertEqual(game.state, "playing")

    def test_name_is_limited_to_eight_characters(self) -> None:
        game = self._game()
        game.state = "name_entry"
        for character in "ABCDEFGHI":
            game._append_name(character)
        self.assertEqual(game.player_name, "ABCDEFGH")

    def test_combo_scoring_and_miss_reset(self) -> None:
        game = self._game()
        game.begin_countdown(100.0)
        game.update(104.0)
        for index in range(3):
            target = game._spawn_target("leak_big", 105.0 + index)
            self.assertEqual(game.handle_shot(target.center, 105.0 + index), "hit")
        self.assertEqual(game.combo, 3)
        self.assertEqual(game.best_combo, 3)
        self.assertEqual(game.score, 350)
        self.assertEqual(game.multiplier, 1.5)
        self.assertEqual(game.handle_shot((10, 740), 109.0), "miss")
        self.assertEqual(game.combo, 0)
        self.assertEqual(game.shots, 4)

    def test_protected_club_logo_penalizes_and_marks_visual_transition(self) -> None:
        game = self._game()
        game.state = "playing"
        game.play_started = 100.0
        game.last_update = 100.0
        game.deadline = 160.0
        game.score = 900
        target = game._spawn_target("logo", 101.0)
        self.assertTrue(game.visual_transition_active)
        self.assertEqual(game.handle_shot(target.center, 101.1), "penalty")
        self.assertEqual(game.score, 400)
        self.assertEqual(game.combo, 0)

    def test_final_pipe_uses_four_scoring_zones_and_moves(self) -> None:
        game = self._game()
        game.state = "playing"
        game.play_started = 100.0
        game.last_update = 146.0
        game.deadline = 160.0
        center = game.final_center
        self.assertEqual(game.handle_shot(center, 146.1), "hit")
        self.assertEqual(game.score, 1000)
        self.assertNotEqual(game.final_center, center)

    def test_result_persists_sorted_top_ten_with_tie_breakers(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scores.json"
            game = self._game(path)
            game.leaderboard = [
                LeaderboardEntry("ALT", 1000, 8, 10, 80.0, 4, "2026-08-09T10:00:00+02:00")
            ]
            game.score = 1000
            game.hits = 9
            game.shots = 10
            game.best_combo = 3
            game._finish(200.0)

            self.assertEqual(game.state, "result")
            self.assertTrue(game.result_qualifies)
            self.assertFalse(path.exists())
            self.assertEqual(
                game.handle_shot(game.result_repeat_button.center, 200.1),
                "handled",
            )
            self.assertEqual(game.state, "name_entry")
            for key in "NEU":
                rect = next(rect for value, rect in game.key_buttons if value == key)
                game.handle_shot(rect.center, 200.2)
            self.assertEqual(game.handle_shot(game.save_name_button.center, 200.3), "saved")
            self.assertTrue(path.exists())
            self.assertEqual(game.leaderboard[0].name, "NEU")
            self.assertEqual(game.current_rank, 1)

    def test_top_ten_name_entry_can_be_skipped_without_saving(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scores.json"
            game = self._game(path)
            game.score = 1200
            game.hits = 6
            game.shots = 8
            game._finish(200.0)

            self.assertTrue(game.result_qualifies)
            self.assertEqual(game.handle_shot(game.result_menu_button.center, 200.1), "skipped")
            self.assertTrue(game.result_skipped)
            self.assertEqual(game.leaderboard, [])
            self.assertFalse(path.exists())

    def test_name_entry_is_not_offered_outside_top_ten(self) -> None:
        game = self._game()
        game.leaderboard = [
            LeaderboardEntry(f"P{index}", 10000 - index, 10, 10, 100.0, 10, str(index))
            for index in range(10)
        ]
        game.score = 50
        game.hits = 1
        game.shots = 3
        game._finish(200.0)

        self.assertFalse(game.result_qualifies)
        self.assertIsNone(game.current_rank)
        self.assertEqual(game.handle_shot(game.result_repeat_button.center, 200.1), "handled")
        self.assertEqual(game.state, "ready")

    def test_hidden_admin_control_requires_pin_before_reset(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scores.json"
            game = self._game(path)
            game.leaderboard = [
                LeaderboardEntry("LENA", 4200, 12, 14, 85.7, 6, "2026-08-10T10:00:00+02:00")
            ]
            game._save_leaderboard()
            self.assertEqual(game.handle_shot(game.admin_button.center, 100.0), "handled")
            self.assertEqual(game.state, "admin")

            for digit in "1111":
                rect = next(rect for value, rect in game.admin_key_buttons if value == digit)
                game.handle_shot(rect.center, 100.1)
            self.assertEqual(game.handle_shot(game.admin_confirm_button.center, 100.2), "admin_denied")
            self.assertEqual(len(game.leaderboard), 1)

            for digit in game.ADMIN_PIN:
                rect = next(rect for value, rect in game.admin_key_buttons if value == digit)
                game.handle_shot(rect.center, 100.3)
            self.assertEqual(game.handle_shot(game.admin_confirm_button.center, 100.4), "admin_reset")
            self.assertEqual(game.state, "ready")
            self.assertEqual(game.leaderboard, [])

    def test_every_state_draws_at_full_screen_size(self) -> None:
        game = self._game()
        for state in ("ready", "name_entry", "admin", "countdown", "playing", "result"):
            game.state = state
            game.state_started = 100.0
            game.play_started = 100.0
            game.last_update = 110.0
            game.deadline = 160.0
            game.draw(110.0)
            self.assertEqual(self.screen.get_size(), (1024, 768))

    def test_logo_transition_expires(self) -> None:
        game = self._game()
        game._visual_transition_until = time.monotonic() - 0.1
        self.assertFalse(game.visual_transition_active)

    def test_moving_targets_except_guarded_logo_are_laser_neutral(self) -> None:
        game = self._game()
        game.state = "playing"
        game.play_started = 100.0
        game.last_update = 127.0
        game.deadline = 160.0
        for kind in ("leak_big", "leak_medium", "leak_small", "ball", "duck", "ring", "gold"):
            game._spawn_target(kind, 127.0)
        game.draw(127.0)

        rgb = pygame.surfarray.array3d(self.screen).astype(np.int16)
        red_excess = rgb[:, :, 0] - np.maximum(rgb[:, :, 1], rgb[:, :, 2])
        self.assertFalse(bool(((rgb[:, :, 0] >= 70) & (red_excess >= 28)).any()))

    def test_every_target_center_provides_red_laser_contrast(self) -> None:
        for kind in ("leak_big", "leak_medium", "leak_small", "ball", "duck", "ring", "gold"):
            with self.subTest(kind=kind):
                game = self._game()
                game.state = "playing"
                game.play_started = 100.0
                game.last_update = 127.0
                game.deadline = 160.0
                target = game._spawn_target(kind, 127.0)
                game.draw(127.0)
                rgb = np.transpose(pygame.surfarray.array3d(self.screen), (1, 0, 2))
                background = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
                detector = PulseShotDetector(DetectionConfig())
                detector.process(background, 0.0)
                detector.process(background, 30.0)
                pulse = background.copy()
                x, y = target.center
                cv2.circle(pulse, (x, y), 3, (12, 20, 245), thickness=-1)

                result = detector.process(pulse, 70.0)

                self.assertTrue(result.shot, kind)
                self.assertLessEqual(abs(result.point[0] - x), 2)
                self.assertLessEqual(abs(result.point[1] - y), 2)

    def test_ducks_spawn_and_remain_in_visible_water_lanes(self) -> None:
        game = self._game()
        duck = game._spawn_target("duck", 100.0)
        self.assertGreaterEqual(duck.y, 570)
        self.assertNotEqual(duck.velocity_x, 0)
        original_x = duck.x
        game.state = "playing"
        game._update_targets(100.1, 0.08)
        self.assertNotEqual(duck.x, original_x)
        self.assertGreaterEqual(duck.y, 570)

    def test_generous_hit_area_counts_edge_of_duck(self) -> None:
        game = self._game()
        game.state = "playing"
        game.play_started = 100.0
        game.last_update = 105.0
        game.deadline = 160.0
        duck = game._spawn_target("duck", 105.0)
        edge_point = (round(duck.x + duck.radius + 28), round(duck.y))

        self.assertEqual(game.handle_shot(edge_point, 105.1), "hit")
        self.assertEqual(game.hits, 1)
