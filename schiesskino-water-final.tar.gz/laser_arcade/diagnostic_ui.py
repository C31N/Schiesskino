from __future__ import annotations

import ctypes
import ctypes.util
import logging
import re
import time
import textwrap
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Deque, Optional, Tuple

import cv2
import numpy as np
import pygame

from .auto_alignment import (
    AlignmentResult,
    VerificationResult,
    detect_projection_quad,
    detect_verification_markers,
)
from .calibration import apply_homography, compute_homography, load_homography
from .apps.cans import CansApp
from .apps.clay_shooting import ClayShootingApp
from .apps.reaction import ReactionApp
from .apps.target_range import TargetRangeApp
from .apps.timed_shooting import TimedShootingApp
from .apps.water_alarm import WaterAlarmApp
from .apps.arcade_common import nearest_laser_button
from .config import Settings
from .constants import (
    APP_DIR,
    TARGET_HISTORY_FILE,
    WATER_ALARM_LEADERBOARD_FILE,
    WEAPON_CALIBRATION_FILE,
)
from .laser_tracker import LaserDetection, LaserTracker
from .weapon_calibration import (
    WeaponCalibration,
    fit_weapon_calibration,
    load_weapon_calibration,
    save_weapon_calibration,
)

LOGGER = logging.getLogger(__name__)


class XFixesCursorController:
    """Steuert den Cursor direkt auf dem SDL-X11-Fenster."""

    def __init__(self) -> None:
        self.display = None
        self.window = 0
        self.hidden = False
        self.x11 = None
        self.xfixes = None
        if pygame.display.get_driver() != "x11":
            return
        try:
            window = int(pygame.display.get_wm_info().get("window", 0))
            x11_path = ctypes.util.find_library("X11")
            xfixes_path = ctypes.util.find_library("Xfixes")
            if not window or not x11_path or not xfixes_path:
                raise RuntimeError("X11-Fenster oder XFixes-Bibliothek fehlt")
            self.x11 = ctypes.CDLL(x11_path)
            self.xfixes = ctypes.CDLL(xfixes_path)
            self.x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
            self.x11.XOpenDisplay.restype = ctypes.c_void_p
            self.x11.XFlush.argtypes = [ctypes.c_void_p]
            self.x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
            self.xfixes.XFixesHideCursor.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
            self.xfixes.XFixesShowCursor.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
            self.display = self.x11.XOpenDisplay(None)
            if not self.display:
                raise RuntimeError("X11-Anzeige konnte nicht geöffnet werden")
            self.window = window
            LOGGER.info("Direkte XFixes-Zeigersteuerung aktiv für Fenster 0x%x", window)
        except Exception as exc:
            LOGGER.warning("Direkte XFixes-Zeigersteuerung nicht verfügbar: %s", exc)
            self.display = None
            self.window = 0

    def hide(self, force: bool = False) -> None:
        if not self.display or not self.window or (self.hidden and not force):
            return
        self.xfixes.XFixesHideCursor(self.display, self.window)
        self.x11.XFlush(self.display)
        self.hidden = True

    def show(self) -> None:
        if not self.display or not self.window or not self.hidden:
            return
        self.xfixes.XFixesShowCursor(self.display, self.window)
        self.x11.XFlush(self.display)
        self.hidden = False

    def close(self) -> None:
        if not self.display:
            return
        # Das Schließen der X11-Verbindung hebt alle von diesem Client
        # gesetzten XFixes-Sperren automatisch auf. Ein zusätzliches
        # XFixesShowCursor kann unter Xwayland mit BadMatch abbrechen.
        self.x11.XCloseDisplay(self.display)
        self.display = None
        self.window = 0
        self.hidden = False


@dataclass
class ShotRecord:
    number: int
    camera_point: Tuple[int, int]
    screen_point: Optional[Tuple[int, int]]
    confidence: float
    timestamp: float


class AutomaticAligner:
    """Schwarz-/Weißmessung mit anschließender unabhängiger Eckprüfung."""

    def __init__(self, screen_size: Tuple[int, int], previous_homography=None):
        self.screen_size = screen_size
        self.homography = previous_homography
        self.corners: Optional[np.ndarray] = None
        self.confidence = 0.0
        self.phase = "idle"
        self.phase_started = 0.0
        self.dark_frames: list[np.ndarray] = []
        self.bright_frames: list[np.ndarray] = []
        self.verification_dark_frames: list[np.ndarray] = []
        self.marker_frames: list[np.ndarray] = []
        self.message = "Automatische Ausrichtung bereit"
        self.last_result: Optional[AlignmentResult] = None
        self.verification: Optional[VerificationResult] = None

    @property
    def active(self) -> bool:
        return self.phase in {
            "warmup",
            "dark_settle",
            "dark_capture",
            "bright_settle",
            "bright_capture",
            "verify_dark_settle",
            "verify_dark_capture",
            "marker_settle",
            "marker_capture",
        }

    @property
    def display_color(self) -> Tuple[int, int, int]:
        if self.phase in {"bright_settle", "bright_capture"}:
            return (255, 255, 255)
        return (0, 0, 0)

    @property
    def shows_markers(self) -> bool:
        return self.phase in {"marker_settle", "marker_capture"}

    @property
    def marker_screen_points(self) -> list[Tuple[int, int]]:
        width, height = self.screen_size
        inset = max(42, int(min(width, height) * 0.065))
        return [
            (inset, inset),
            (width - 1 - inset, inset),
            (width - 1 - inset, height - 1 - inset),
            (inset, height - 1 - inset),
        ]

    def start(self, now: Optional[float] = None) -> None:
        self.phase = "warmup"
        self.phase_started = now if now is not None else time.monotonic()
        self.dark_frames.clear()
        self.bright_frames.clear()
        self.verification_dark_frames.clear()
        self.marker_frames.clear()
        self.verification = None
        self.message = "Kamera stabilisiert sich"

    def feed(self, frame_rgb: np.ndarray, now: float) -> bool:
        """Liefert True genau dann, wenn ein Ausrichtversuch beendet wurde."""

        elapsed = now - self.phase_started
        if self.phase == "warmup" and elapsed >= 1.0:
            self._advance("dark_settle", now, "Schwarzbild wird gemessen")
        elif self.phase == "dark_settle" and elapsed >= 0.55:
            self._advance("dark_capture", now, "Schwarzbild wird aufgenommen")
        elif self.phase == "dark_capture":
            self.dark_frames.append(frame_rgb.copy())
            if elapsed >= 0.40 and len(self.dark_frames) >= 8:
                self._advance("bright_settle", now, "Weißbild wird gemessen")
        elif self.phase == "bright_settle" and elapsed >= 0.80:
            self._advance("bright_capture", now, "Projektionsfläche wird aufgenommen")
        elif self.phase == "bright_capture":
            self.bright_frames.append(frame_rgb.copy())
            if elapsed >= 0.40 and len(self.bright_frames) >= 8:
                return self._finish_alignment(now)
        elif self.phase == "verify_dark_settle" and elapsed >= 0.45:
            self._advance("verify_dark_capture", now, "Eckprüfung: Referenzbild")
        elif self.phase == "verify_dark_capture":
            self.verification_dark_frames.append(frame_rgb.copy())
            if elapsed >= 0.32 and len(self.verification_dark_frames) >= 7:
                self._advance("marker_settle", now, "Vier Eckmarker werden geprüft")
        elif self.phase == "marker_settle" and elapsed >= 0.60:
            self._advance("marker_capture", now, "Eckmarker werden zurückgemessen")
        elif self.phase == "marker_capture":
            self.marker_frames.append(frame_rgb.copy())
            if elapsed >= 0.35 and len(self.marker_frames) >= 7:
                self._finish_verification()
                return True
        return False

    def _advance(self, phase: str, now: float, message: str) -> None:
        self.phase = phase
        self.phase_started = now
        self.message = message

    def _finish_alignment(self, now: float) -> bool:
        try:
            result = detect_projection_quad(self.dark_frames, self.bright_frames)
            width, height = self.screen_size
            screen_points = [
                (0, 0),
                (width - 1, 0),
                (width - 1, height - 1),
                (0, height - 1),
            ]
            camera_points = [tuple(int(round(v)) for v in point) for point in result.corners]
            data = compute_homography(camera_points, screen_points)
            self.homography = data.homography
            self.corners = result.corners
            self.confidence = result.confidence
            self.last_result = result
            APP_DIR.mkdir(parents=True, exist_ok=True)
            cv2.imwrite(str(APP_DIR / "alignment_difference.png"), result.difference)
            cv2.imwrite(str(APP_DIR / "alignment_mask.png"), result.mask)
            LOGGER.info(
                "Automatische Ausrichtung erfolgreich: confidence=%.3f corners=%s",
                result.confidence,
                camera_points,
            )
            self._advance("verify_dark_settle", now, "Ausrichtung gefunden – Ecken werden geprüft")
            return False
        except Exception as exc:
            self._fail("Automatische Ausrichtung fehlgeschlagen", exc)
            return True

    def _finish_verification(self) -> None:
        try:
            if self.homography is None:
                raise RuntimeError("Keine Homographie für die Eckprüfung vorhanden")
            verification = detect_verification_markers(
                self.verification_dark_frames,
                self.marker_frames,
                self.homography,
                self.marker_screen_points,
            )
            self.verification = verification
            self.phase = "success"
            self.message = (
                f"4/4 Ecken bestätigt · max. Abweichung {verification.max_error:.0f} px"
            )
            cv2.imwrite(str(APP_DIR / "alignment_verification_mask.png"), verification.mask)
            LOGGER.info(
                "Eckprüfung erfolgreich: 4/4 max_error=%.2f errors=%s",
                verification.max_error,
                [round(float(value), 2) for value in verification.errors],
            )
        except Exception as exc:
            self._fail("Eckprüfung fehlgeschlagen", exc)

    def _fail(self, prefix: str, exc: Exception) -> None:
        self.homography = None
        self.corners = None
        self.confidence = 0.0
        self.verification = None
        self.phase = "failed"
        self.message = str(exc)
        LOGGER.exception("%s: %s", prefix, exc)


class LaserDiagnosticUI:
    """Reduzierte Oberfläche für Ausrichtung und Schusserkennung."""

    CURSOR_HIDE_DELAY = 1.5

    BG = (13, 17, 25)
    PANEL = (25, 32, 45)
    BORDER = (72, 91, 116)
    TEXT = (235, 241, 248)
    MUTED = (155, 172, 194)
    CYAN = (35, 215, 235)
    GREEN = (75, 220, 135)
    # Rot darf die Kameraansicht selbst nicht enthalten: Sonst würde die
    # projizierte Diagnoseoberfläche zum Schusskandidaten. Kandidaten und Fehler
    # werden deshalb bewusst blau/violett markiert.
    YELLOW = (75, 145, 255)
    RED = (185, 125, 255)
    # Das Zielbild verwendet absichtlich keinen roten RGB-Anteil. Bei einem
    # DLP-Beamer können selbst weiße Linien als kurze rote Farbblitze in der
    # Kamera erscheinen und damit einen falschen Lasertreffer auslösen.
    TARGET_BG = (0, 8, 16)
    TARGET_CYAN = (0, 205, 245)
    TARGET_GREEN = (0, 225, 120)
    TARGET_MUTED = (0, 82, 118)

    def __init__(
        self,
        screen: pygame.Surface,
        settings: Settings,
        tracker: LaserTracker,
        weapon_calibration_path: Optional[Path] = WEAPON_CALIBRATION_FILE,
        target_history_path: Optional[Path] = TARGET_HISTORY_FILE,
        water_alarm_leaderboard_path: Optional[Path] = WATER_ALARM_LEADERBOARD_FILE,
    ):
        self.screen = screen
        self.settings = settings
        self.tracker = tracker
        stored = load_homography()
        self.aligner = AutomaticAligner(screen.get_size(), stored.homography)
        self.aligner.start()
        self.shots: Deque[ShotRecord] = deque(maxlen=32)
        self.next_shot_number = 1
        self.sighting_step = 0
        self.sighting_phase = "shooting"
        self.stage_shots: list[ShotRecord] = []
        self.completed_groups: list[list[ShotRecord]] = [[] for _ in range(5)]
        self.weapon_calibration_path = weapon_calibration_path
        self.weapon_calibration = (
            load_weapon_calibration(weapon_calibration_path, screen.get_size())
            if weapon_calibration_path is not None
            else WeaponCalibration()
        )
        self.weapon_calibration_message = (
            self._weapon_calibration_text()
            if self.weapon_calibration.active
            else "Waffenkorrektur wird nach dem 17. Schuss gespeichert"
        )
        self.last_detection: Optional[LaserDetection] = None
        self.last_frame_rgb: Optional[np.ndarray] = None
        self.last_mask_rgb: Optional[np.ndarray] = None
        self.armed_at = float("inf")
        # Beim reinen Pistolenbetrieb sofort ausblenden. Eine echte Bewegung
        # macht den Zeiger jederzeit wieder sichtbar.
        self.last_mouse_activity = time.monotonic() - self.CURSOR_HIDE_DELAY
        self.last_mouse_position = pygame.mouse.get_pos()
        self.physical_mouse_connected = self._physical_mouse_connected()
        self.last_mouse_probe = time.monotonic()
        LOGGER.info(
            "Physische Maus erkannt: %s", "ja" if self.physical_mouse_connected else "nein"
        )
        self.cursor_hidden = False
        self.default_cursor = None
        self.transparent_cursor = None
        try:
            self.default_cursor = pygame.mouse.get_cursor()
            blank = (0,) * 8
            self.transparent_cursor = pygame.cursors.Cursor(
                (8, 8), (0, 0), blank, blank
            )
        except pygame.error:
            LOGGER.debug("Transparenter Mauszeiger wird von SDL nicht unterstützt")
        pygame.mouse.set_visible(True)
        self.xfixes_cursor = XFixesCursorController()
        self.font_small = pygame.font.SysFont("Arial", 17)
        self.font = pygame.font.SysFont("Arial", 22)
        self.font_large = pygame.font.SysFont("Arial", 34, bold=True)
        self.font_title = pygame.font.SysFont("Arial", 38, bold=True)
        self.font_target = pygame.font.SysFont("Arial", 46, bold=True)
        self.font_menu_title = pygame.font.SysFont("Arial", 54, bold=True)
        self.font_card = pygame.font.SysFont("Arial", 25, bold=True)
        self.card_font_cache: dict[tuple[str, int], pygame.font.Font] = {}
        self.view_mode = "diagnostic"
        self.return_view_mode = "menu"
        self.selected_game = ""
        self.close_requested = False
        self.diagnostic_target_button = pygame.Rect(790, 522, 200, 42)
        self.align_button = pygame.Rect(790, 574, 200, 42)
        self.clear_button = pygame.Rect(790, 626, 200, 42)
        self.diagnostic_close_button = pygame.Rect(790, 678, 200, 42)
        screen_width, screen_height = self.screen.get_size()
        footer_y = screen_height - 64
        self.target_menu_button = pygame.Rect(screen_width // 2 - 370, footer_y, 140, 36)
        self.target_live_button = pygame.Rect(screen_width // 2 - 220, footer_y, 170, 36)
        self.target_align_button = pygame.Rect(screen_width // 2 - 40, footer_y, 220, 36)
        self.target_clear_button = pygame.Rect(screen_width // 2 + 190, footer_y, 180, 36)
        self.menu_sighting_button = pygame.Rect(screen_width // 2 - 325, footer_y, 200, 36)
        self.menu_camera_button = pygame.Rect(screen_width // 2 - 105, footer_y, 200, 36)
        self.menu_align_button = pygame.Rect(screen_width // 2 + 115, footer_y, 210, 36)
        self.advance_button = pygame.Rect(screen_width // 2 - 160, screen_height - 120, 320, 44)
        self.cans_game = CansApp(self.screen)
        shared_sounds = self.cans_game.sounds
        self.clay_game = ClayShootingApp(self.screen, sounds=shared_sounds)
        self.timed_game = TimedShootingApp(self.screen, sounds=shared_sounds)
        self.reaction_game = ReactionApp(self.screen, sounds=shared_sounds)
        self.target_range_game = TargetRangeApp(
            self.screen,
            sounds=shared_sounds,
            history_path=target_history_path,
        )
        self.water_alarm_game = WaterAlarmApp(
            self.screen,
            sounds=shared_sounds,
            leaderboard_path=water_alarm_leaderboard_path,
        )
        self.standard_game_states = {
            id(game): game.state for game in self._standard_games()
        }
        self.standard_visual_transitions = {
            id(game): False for game in self._standard_games()
        }
        # Alte Moorhuhn-Sonderpfade bleiben während der Migration inaktiv.
        self.chicken_game = None
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False

    def _standard_games(self) -> tuple:
        return (
            self.cans_game,
            self.clay_game,
            self.timed_game,
            self.reaction_game,
            self.target_range_game,
            self.water_alarm_game,
        )

    def _standard_game_for_view(self):
        if self.aligner.phase != "success":
            return None
        games = {
            "cans": self.cans_game,
            "clay": self.clay_game,
            "timed": self.timed_game,
            "reaction": self.reaction_game,
            "range": self.target_range_game,
            "water": self.water_alarm_game,
        }
        return games.get(self.view_mode)

    def _stop_standard_games(self, except_game=None) -> None:
        for game in self._standard_games():
            if game is not except_game:
                game.stop()

    def handle_event(self, event: pygame.event.Event) -> bool:
        if self.close_requested:
            return False
        if event.type == pygame.MOUSEMOTION and self.physical_mouse_connected:
            position = tuple(getattr(event, "pos", pygame.mouse.get_pos()))
            delta_x = position[0] - self.last_mouse_position[0]
            delta_y = position[1] - self.last_mouse_position[1]
            self.last_mouse_position = position
            # Wayland kann unveränderte oder minimale synthetische
            # Bewegungsereignisse liefern. Nur eine echte Bewegung zählt.
            if delta_x * delta_x + delta_y * delta_y >= 4:
                self._mark_mouse_activity()
        elif self.physical_mouse_connected and event.type in {
            pygame.MOUSEBUTTONDOWN,
            pygame.MOUSEBUTTONUP,
            pygame.MOUSEWHEEL,
        }:
            self._mark_mouse_activity()
        if event.type == pygame.QUIT:
            return False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                return False
            if self.view_mode == "water" and self.aligner.phase == "success":
                action = self.water_alarm_game.handle_key(event)
                if action == "menu":
                    self._show_menu()
                return True
            if event.key == pygame.K_a:
                self.start_alignment()
            elif event.key == pygame.K_c:
                self.clear_shots()
            elif event.key == pygame.K_l and not self.aligner.active:
                self._toggle_view()
            elif event.key == pygame.K_m and not self.aligner.active:
                self._show_menu()
            elif event.key in {pygame.K_SPACE, pygame.K_RETURN, pygame.K_n}:
                self._advance_sighting()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            standard_game = self._standard_game_for_view()
            if standard_game is not None:
                action = standard_game.handle_shot(event.pos)
                if action == "menu":
                    self._show_menu()
            elif (
                self.view_mode == "chickens"
                and self.aligner.phase == "success"
                and self.chicken_game is not None
            ):
                action = self.chicken_game.handle_shot(event.pos)
                if action == "menu":
                    self._show_menu()
            elif self.view_mode == "target" and self.aligner.phase == "success":
                if self.advance_button.collidepoint(event.pos) and self.sighting_phase in {
                    "evaluation",
                    "complete",
                }:
                    self._advance_sighting()
                elif self.target_live_button.collidepoint(event.pos):
                    self._toggle_view()
                elif self.target_menu_button.collidepoint(event.pos):
                    self._show_menu()
                elif self.target_align_button.collidepoint(event.pos):
                    self.start_alignment()
                elif self.target_clear_button.collidepoint(event.pos):
                    self.clear_shots()
            elif self.view_mode == "menu" and self.aligner.phase == "success":
                selected = self._menu_entry_at(event.pos)
                if selected is not None:
                    self._select_game(*selected)
                elif self.menu_sighting_button.collidepoint(event.pos):
                    self._start_sighting()
                elif self.menu_camera_button.collidepoint(event.pos):
                    self._toggle_view()
                elif self.menu_align_button.collidepoint(event.pos):
                    self.start_alignment()
            elif self.view_mode == "coming_soon" and self.aligner.phase == "success":
                if self._coming_soon_rect().collidepoint(event.pos):
                    self._show_menu()
            else:
                if self.diagnostic_target_button.collidepoint(event.pos):
                    self._show_menu()
                elif self.align_button.collidepoint(event.pos):
                    self.start_alignment()
                elif self.clear_button.collidepoint(event.pos):
                    self.clear_shots()
                elif self.diagnostic_close_button.collidepoint(event.pos):
                    self._request_program_close()
        return True

    def _mark_mouse_activity(self, now: Optional[float] = None) -> None:
        if not self.physical_mouse_connected:
            return
        self.last_mouse_activity = now if now is not None else time.monotonic()
        was_hidden = self.cursor_hidden
        if self.default_cursor is not None:
            try:
                pygame.mouse.set_cursor(self.default_cursor)
            except pygame.error:
                LOGGER.debug("Standard-Mauszeiger konnte nicht wiederhergestellt werden")
        self.xfixes_cursor.show()
        pygame.mouse.set_visible(True)
        self.cursor_hidden = False
        if was_hidden:
            LOGGER.info("Mausbewegung erkannt: Mauszeiger eingeblendet")

    def _update_cursor_visibility(self, now: Optional[float] = None) -> None:
        current = now if now is not None else time.monotonic()
        if current - self.last_mouse_probe >= 2.0:
            was_connected = self.physical_mouse_connected
            self.physical_mouse_connected = self._physical_mouse_connected()
            self.last_mouse_probe = current
            if self.physical_mouse_connected and not was_connected:
                # Eine im reinen Pistolenbetrieb aufgebaute XFixes-Sperre wird
                # durch das Schließen dieser separaten X11-Verbindung sicher
                # und vollständig freigegeben. Danach beginnt ein frischer
                # Controller ohne verschachtelte Hide-Zähler.
                self.xfixes_cursor.close()
                self.xfixes_cursor = XFixesCursorController()
                self.last_mouse_position = pygame.mouse.get_pos()
                self.last_mouse_activity = current
                if self.default_cursor is not None:
                    try:
                        pygame.mouse.set_cursor(self.default_cursor)
                    except pygame.error:
                        LOGGER.debug(
                            "Standard-Mauszeiger konnte nach dem Anschließen "
                            "nicht wiederhergestellt werden"
                        )
                pygame.mouse.set_visible(True)
                self.cursor_hidden = False
                LOGGER.info("Maus angeschlossen: Mauszeiger freigegeben")
            elif was_connected and not self.physical_mouse_connected:
                LOGGER.info("Maus entfernt: Mauszeiger dauerhaft ausgeblendet")
        if not self.physical_mouse_connected:
            # Ohne physisches Zeigegerät bleibt der Cursor permanent verborgen.
            # Das erzwungene XFixes-Signal in jedem Bild neutralisiert auch
            # synthetische Xwayland-Bewegungsereignisse.
            pygame.mouse.set_visible(False)
            self.xfixes_cursor.hide(force=True)
            self.cursor_hidden = True
            return
        if not self.cursor_hidden and current - self.last_mouse_activity >= self.CURSOR_HIDE_DELAY:
            if self.transparent_cursor is not None:
                try:
                    pygame.mouse.set_cursor(self.transparent_cursor)
                except pygame.error:
                    LOGGER.debug("Transparenter Mauszeiger konnte nicht gesetzt werden")
            pygame.mouse.set_visible(False)
            # SDL allein blendet den Hardwarezeiger unter Xwayland nicht immer
            # zuverlässig aus. XFixes wird hier genau einmal gesetzt und bei
            # der nächsten echten Mausbewegung in _mark_mouse_activity gelöst.
            self.xfixes_cursor.hide()
            self.cursor_hidden = True
            LOGGER.info("Mauszeiger wegen Inaktivität ausgeblendet")

    @staticmethod
    def _physical_mouse_connected() -> bool:
        roots = (Path("/dev/input/by-id"), Path("/dev/input/by-path"))
        if any(
            path.is_dir() and any(path.glob("*event-mouse"))
            for path in roots
        ):
            return True

        # Bluetooth-Kombigeräte (Tastatur mit Touchpad) besitzen auf Raspberry
        # Pi OS häufig keinen by-id-/by-path-Symlink. Der Kernel weist ihren
        # separaten Zeigerkanal aber eindeutig als ``mouseN`` aus.
        try:
            devices = Path("/proc/bus/input/devices").read_text(
                encoding="utf-8", errors="replace"
            )
        except OSError:
            return False
        return LaserDiagnosticUI._input_devices_include_mouse(devices)

    @staticmethod
    def _input_devices_include_mouse(devices: str) -> bool:
        return any(
            re.search(r"\bmouse\d+\b", line) is not None
            for line in devices.splitlines()
            if line.startswith("H: Handlers=")
        )

    def close(self) -> None:
        self._stop_standard_games()
        if self.chicken_game is not None:
            self.chicken_game.stop()
        # SDL merkt sich auch einen transparenten Cursor über das Ende des
        # Vollbildfensters hinaus. Vor dem Schließen deshalb zuerst Form und
        # Sichtbarkeit ausdrücklich auf den normalen Desktop-Zeiger setzen.
        if self.default_cursor is not None:
            try:
                pygame.mouse.set_cursor(self.default_cursor)
            except pygame.error:
                LOGGER.debug("Standard-Mauszeiger konnte beim Beenden nicht gesetzt werden")
        try:
            pygame.mouse.set_visible(True)
            pygame.event.pump()
            self.cursor_hidden = False
        except pygame.error:
            LOGGER.debug("Mauszeiger konnte beim Beenden nicht freigegeben werden")
        self.xfixes_cursor.close()

    def _toggle_view(self) -> None:
        if self.aligner.phase != "success":
            self.view_mode = "diagnostic"
            return
        if self.view_mode == "diagnostic":
            self.view_mode = self.return_view_mode
        else:
            self.return_view_mode = self.view_mode
            self.view_mode = "diagnostic"
        strict_moorhuhn = (
            self.view_mode == "chickens"
            and self.chicken_game is not None
            and self.chicken_game.state == "playing"
        )
        self.tracker.set_moorhuhn_filter(strict_moorhuhn)
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def _show_menu(self) -> None:
        if self.aligner.phase != "success":
            return
        self._stop_standard_games()
        if self.chicken_game is not None:
            self.chicken_game.stop()
        self.tracker.set_moorhuhn_filter(False)
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False
        self.view_mode = "menu"
        self.return_view_mode = "menu"
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def _request_program_close(self) -> None:
        LOGGER.info("Programmende über Kamerabild-Menü angefordert")
        self.close_requested = True

    def _start_sighting(self) -> None:
        self._stop_standard_games()
        if self.chicken_game is not None:
            self.chicken_game.stop()
        self.tracker.set_moorhuhn_filter(False)
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False
        self._reset_sighting_session()
        self.view_mode = "target"
        self.return_view_mode = "target"
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def _select_game(self, name: str, available: bool) -> None:
        LOGGER.info("Menüauswahl: %s", name)
        if available and name == "DOSENSCHIE\u00dfEN":
            self._start_standard_game("cans", self.cans_game, "Dosenschießen")
            return
        if available and name == "TONTAUBENSCHIE\u00dfEN":
            self._start_standard_game("clay", self.clay_game, "Tontaubenschießen")
            return
        if available and name == "ZEITSCHIE\u00dfEN":
            self._start_standard_game("timed", self.timed_game, "Zeitschießen")
            return
        if available and name == "WASSER-ALARM":
            self._start_standard_game("water", self.water_alarm_game, "Wasser-Alarm")
            return
        if available and name == "REAKTION":
            self._start_standard_game("reaction", self.reaction_game, "Reaktion")
            return
        if available and name == "ZIELSCHEIBE":
            self._start_standard_game("range", self.target_range_game, "Zielscheibe")
            return
        self.selected_game = name
        self.view_mode = "coming_soon"
        self.return_view_mode = "menu"
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def _start_standard_game(self, view_mode: str, game, label: str) -> None:
        self._stop_standard_games(except_game=game)
        if self.chicken_game is not None:
            self.chicken_game.stop()
        self.tracker.set_moorhuhn_filter(False)
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False
        game.start()
        self.standard_game_states[id(game)] = game.state
        self.standard_visual_transitions[id(game)] = False
        self.view_mode = view_mode
        self.return_view_mode = view_mode
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8
        LOGGER.info("%s geöffnet", label)

    def _start_chicken_game(self) -> None:
        self._stop_standard_games()
        self.tracker.set_moorhuhn_filter(False)
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False
        if self.chicken_game is None:
            self.chicken_game = ChickenApp(self.screen)
        self.chicken_game.start()
        self.view_mode = "chickens"
        self.return_view_mode = "chickens"
        self.tracker.reset_state()
        # Das Laden der umfangreichen Originalgrafiken und der Wechsel vom roten
        # Originalmenü dürfen nicht als Laserschuss übernommen werden.
        self.armed_at = time.monotonic() + 1.2
        LOGGER.info("Moorhuhn geöffnet")

    def start_alignment(self) -> None:
        self._stop_standard_games()
        if self.chicken_game is not None:
            self.chicken_game.stop()
        self.tracker.set_moorhuhn_filter(False)
        self.chicken_pan_was_moving = False
        self.chicken_visual_transition = False
        self._reset_sighting_session()
        self.tracker.reset_state()
        self.aligner.start()
        self.armed_at = float("inf")
        self.view_mode = "diagnostic"

    def clear_shots(self) -> None:
        self._reset_sighting_session()
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def _reset_sighting_session(self) -> None:
        self.shots.clear()
        self.next_shot_number = 1
        self.sighting_step = 0
        self.sighting_phase = "shooting"
        self.stage_shots = []
        self.completed_groups = [[] for _ in range(5)]

    def _advance_sighting(self) -> None:
        if self.aligner.phase != "success":
            return
        if self.sighting_phase == "evaluation":
            if self.sighting_step < 4:
                self.sighting_step += 1
                self.stage_shots = []
                self.sighting_phase = "shooting"
            else:
                self.sighting_phase = "complete"
        elif self.sighting_phase == "complete":
            self._reset_sighting_session()
        else:
            return
        # Der Wechsel der projizierten Zielgrafik darf nicht als Laserimpuls
        # in den nächsten Abschnitt übernommen werden.
        self.tracker.reset_state()
        self.armed_at = time.monotonic() + 0.8

    def update(self, detection: LaserDetection, now: float) -> None:
        self.last_detection = detection
        if detection.frame_preview is not None:
            self.last_frame_rgb = detection.frame_preview
        if detection.mask_preview is not None:
            self.last_mask_rgb = detection.mask_preview

        if self.aligner.active:
            if self.last_frame_rgb is not None:
                finished = self.aligner.feed(self.last_frame_rgb, now)
                if finished:
                    # Schwarz/Weiß-Umschaltung nicht als Schuss interpretieren.
                    self.tracker.reset_state()
                    self.armed_at = now + 1.5
                    self.view_mode = (
                        "menu" if self.aligner.phase == "success" else "diagnostic"
                    )
                    if self.aligner.phase == "success":
                        self._reset_sighting_session()
                        self.return_view_mode = "menu"
            return

        standard_game = self._standard_game_for_view()
        if standard_game is not None:
            previous_game_state = self.standard_game_states.get(
                id(standard_game), standard_game.state
            )
            standard_game.update(now)
            current_game_state = standard_game.state
            self.standard_game_states[id(standard_game)] = current_game_state
            if current_game_state != previous_game_state:
                # Countdown, Rundenwechsel und Ergebnisansichten verändern
                # große Teile des projizierten Bildes. Diese Umschaltung darf
                # nicht als neuer Laserimpuls in das Spiel zurücklaufen.
                self.tracker.reset_state()
                self.armed_at = now + 0.4
                LOGGER.info(
                    "%s: Bildübergang %s → %s, Schusserkennung kurz gesperrt",
                    standard_game.name,
                    previous_game_state,
                    current_game_state,
                )
                return
            transition_active = bool(
                getattr(standard_game, "visual_transition_active", False)
            )
            transition_was_active = self.standard_visual_transitions.get(
                id(standard_game), False
            )
            self.standard_visual_transitions[id(standard_game)] = transition_active
            if transition_active:
                # Besonders das rote Original-Vereinslogo wird als Schutzziel
                # eingeblendet. Der Grafikwechsel selbst ist kein Laserschuss.
                return
            if transition_was_active:
                self.tracker.reset_state()
                self.armed_at = now + 0.30
                LOGGER.info(
                    "%s: dynamischer Bildübergang beendet, Schusserkennung neu bereit",
                    standard_game.name,
                )
                return
        elif (
            self.view_mode == "chickens"
            and self.aligner.phase == "success"
            and self.chicken_game is not None
        ):
            previous_chicken_state = self.chicken_game.state
            self.chicken_game.update(now)
            if self.chicken_game.state != previous_chicken_state:
                if self.chicken_game.state == "playing":
                    self.tracker.set_moorhuhn_filter(True)
                    self.armed_at = now + 0.35
                    LOGGER.info("Moorhuhn: Schusserkennung für bewegte Spielszene bereit")
                    return
                if previous_chicken_state == "playing":
                    self.tracker.set_moorhuhn_filter(False)
                    self.armed_at = now + 0.35
                    return
            if self.chicken_game.state == "playing" and self.chicken_game.visual_transition_active:
                self.chicken_visual_transition = True
                return
            if self.chicken_visual_transition:
                self.chicken_visual_transition = False
                self.tracker.reset_state()
                self.armed_at = now + 0.25
                LOGGER.info("Moorhuhn: Bildübergang beendet, Schusserkennung neu bereit")
                return
            pan_is_moving = (
                self.chicken_game.state == "playing"
                and abs(self.chicken_game.camera - self.chicken_game.camera_target) > 0.004
            )
            if pan_is_moving:
                self.chicken_pan_was_moving = True
                return
            if self.chicken_pan_was_moving:
                self.chicken_pan_was_moving = False
                self.tracker.reset_state()
                self.armed_at = now + 0.35
                LOGGER.info("Moorhuhn: Panorama steht, Schusserkennung neu bereit")
                return

        if now < self.armed_at:
            return
        if not detection.shot or detection.point is None:
            return

        raw_mapped = None
        if self.aligner.homography is not None:
            raw_mapped = apply_homography(self.aligner.homography, detection.point)
            width, height = self.screen.get_size()
            raw_mapped = (
                max(0, min(width - 1, raw_mapped[0])),
                max(0, min(height - 1, raw_mapped[1])),
            )
        mapped = (
            self.weapon_calibration.apply(raw_mapped, self.screen.get_size())
            if raw_mapped is not None
            else None
        )
        standard_game = self._standard_game_for_view()
        if mapped is not None and standard_game is not None:
            action = standard_game.handle_shot(mapped, now)
            LOGGER.info(
                "%s: Schuss bei Bildschirm=%s, Ergebnis=%s",
                standard_game.name,
                mapped,
                action,
            )
            if action == "menu":
                self._show_menu()
            return
        if mapped is not None and self.view_mode == "chickens" and self.chicken_game is not None:
            # Nur die laufende Spielszene enthält bewegte rote Kämme. In den
            # statischen Menüs würde diese Zusatzschwelle einen echten Laser auf
            # einem roten Button unnötig abschwächen oder vollständig sperren.
            if self.chicken_game.state == "playing" and not self.chicken_game.is_laser_signature(
                detection.peak_red_excess, detection.peak_delta
            ):
                LOGGER.info(
                    "Moorhuhn: rote Spielanimation verworfen bei Bildschirm=%s, "
                    "Fläche=%.1f, Rotüberschuss=%s, Änderung=%s",
                    mapped,
                    detection.area,
                    detection.peak_red_excess,
                    detection.peak_delta,
                )
                return
            action = self.chicken_game.handle_shot(mapped, now)
            LOGGER.info(
                "Moorhuhn: Schuss bei Bildschirm=%s, Ergebnis=%s, Fläche=%.1f, "
                "Rotüberschuss=%s, Änderung=%s, Sicherheit=%.2f",
                mapped,
                action,
                detection.area,
                detection.peak_red_excess,
                detection.peak_delta,
                detection.confidence,
            )
            if action == "menu":
                self._show_menu()
            return
        if mapped is not None and self._handle_laser_control(mapped):
            return
        if self.view_mode != "target":
            return
        if self.aligner.phase == "success" and self.sighting_phase != "shooting":
            return
        record = ShotRecord(
            number=self.next_shot_number,
            camera_point=detection.point,
            # Beim Einschießen wird bewusst die unkorrigierte Treffpunktlage
            # gespeichert. Nur so kann eine neue Waffenabweichung gemessen werden.
            screen_point=raw_mapped,
            confidence=detection.confidence,
            timestamp=time.time(),
        )
        self.shots.append(record)
        self.stage_shots.append(record)
        self.next_shot_number += 1
        required = 5 if self.sighting_step == 0 else 3
        if len(self.stage_shots) >= required:
            self.completed_groups[self.sighting_step] = list(self.stage_shots)
            # Nach dem 17. Schuss direkt abschließen; die letzte Ecke ist
            # bereits Teil der Gesamtauswertung und braucht keinen Extra-Klick.
            self.sighting_phase = "complete" if self.sighting_step == 4 else "evaluation"
            if self.sighting_step == 4:
                self._calibrate_weapon_from_sighting()
            self.tracker.reset_state()
        LOGGER.info(
            "SCHUSS #%s Kamera=%s Bildschirm=%s Confidence=%.3f Area=%.1f Rot=%s Delta=%s",
            record.number,
            record.camera_point,
            record.screen_point,
            record.confidence,
            detection.area,
            detection.peak_red_excess,
            detection.peak_delta,
        )

    def _calibrate_weapon_from_sighting(self) -> None:
        stages = self._sighting_stages()
        groups = [
            [shot.screen_point for shot in group if shot.screen_point is not None]
            for group in self.completed_groups
        ]
        try:
            calibration = fit_weapon_calibration(
                groups,
                [stage[3] for stage in stages],
                self.screen.get_size(),
            )
            self.weapon_calibration = calibration
            self.weapon_calibration_message = self._weapon_calibration_text()
            if self.weapon_calibration_path is not None:
                save_weapon_calibration(
                    self.weapon_calibration_path,
                    calibration,
                    self.screen.get_size(),
                )
            LOGGER.info(
                "Waffenkalibrierung gespeichert: Korrektur x=%+.1f y=%+.1f, "
                "Restabweichung=%.1f px, Schüsse=%s",
                calibration.offset_x,
                calibration.offset_y,
                calibration.residual_px,
                calibration.sample_count,
            )
        except (ValueError, OSError) as exc:
            self.weapon_calibration_message = f"Waffenkorrektur nicht gespeichert: {exc}"
            LOGGER.warning("Waffenkalibrierung fehlgeschlagen: %s", exc)

    def _weapon_calibration_text(self) -> str:
        calibration = self.weapon_calibration
        return (
            f"Waffenkorrektur aktiv: X {calibration.offset_x:+.0f} px  ·  "
            f"Y {calibration.offset_y:+.0f} px  ·  Qualität ±{calibration.residual_px:.0f} px"
        )

    def _menu_entries(
        self,
    ) -> list[tuple[pygame.Rect, str, str, bool]]:
        width, _ = self.screen.get_size()
        margin = 50
        gap = 18
        card_width = (width - 2 * margin - 2 * gap) // 3
        card_height = 210
        definitions = [
            ("TONTAUBENSCHIE\u00dfEN", "Fliegende Ziele klassisch treffen", True),
            ("DOSENSCHIE\u00dfEN", "Dosen schnell und präzise treffen", True),
            ("ZEITSCHIE\u00dfEN", "Treffer gegen die laufende Uhr", True),
            ("WASSER-ALARM", "60 Sekunden Wasser-Arcade für alle", True),
            ("REAKTION", "Ziele erkennen und sofort reagieren", True),
            ("ZIELSCHEIBE", "Variable Wertung und Ergebnisverlauf", True),
        ]
        entries: list[tuple[pygame.Rect, str, str, bool]] = []
        for index, (name, subtitle, available) in enumerate(definitions):
            column = index % 3
            row = index // 3
            rect = pygame.Rect(
                margin + column * (card_width + gap),
                150 + row * 228,
                card_width,
                card_height,
            )
            entries.append((rect, name, subtitle, available))
        return entries

    def _menu_entry_at(self, point: Tuple[int, int]) -> Optional[tuple[str, bool]]:
        entries = self._menu_entries()
        selected = nearest_laser_button(
            point,
            ((index, entry[0]) for index, entry in enumerate(entries)),
        )
        if selected is None:
            return None
        _, name, _, available = entries[selected]
        return name, available

    def _coming_soon_rect(self) -> pygame.Rect:
        width, height = self.screen.get_size()
        card = pygame.Rect(0, 0, 660, 350)
        card.center = (width // 2, height // 2 + 20)
        return card

    def _handle_laser_control(self, point: Tuple[int, int]) -> bool:
        """Führt eine sichtbare Schaltfläche durch einen Lasertreffer aus."""

        controls: list[tuple[pygame.Rect, str, Callable[[], None]]] = []
        if self.view_mode == "target" and self.aligner.phase == "success":
            if self.sighting_phase == "evaluation":
                controls.append(
                    (self._stage_evaluation_rect(), "AUSWERTUNG / WEITER", self._advance_sighting)
                )
                controls.append((self.advance_button, "WEITER", self._advance_sighting))
            elif self.sighting_phase == "complete":
                controls.append(
                    (
                        self._complete_evaluation_rect(),
                        "GESAMTAUSWERTUNG / WIEDERHOLEN",
                        self._advance_sighting,
                    )
                )
                controls.append((self.advance_button, "WEITER", self._advance_sighting))
            controls.extend(
                [
                    (self.target_menu_button, "MENÜ", self._show_menu),
                    (self.target_live_button, "KAMERABILD", self._toggle_view),
                    (self.target_align_button, "NEU AUSRICHTEN", self.start_alignment),
                    (self.target_clear_button, "ABLAUF NEU", self.clear_shots),
                ]
            )
        elif self.view_mode == "menu" and self.aligner.phase == "success":
            for rect, name, _, available in self._menu_entries():
                controls.append(
                    (
                        rect,
                        name,
                        lambda game=name, ready=available: self._select_game(game, ready),
                    )
                )
            controls.extend(
                [
                    (self.menu_sighting_button, "EINSCHIE\u00dfEN", self._start_sighting),
                    (self.menu_camera_button, "KAMERABILD", self._toggle_view),
                    (self.menu_align_button, "NEU AUSRICHTEN", self.start_alignment),
                ]
            )
        elif self.view_mode == "coming_soon" and self.aligner.phase == "success":
            controls.append((self._coming_soon_rect(), "ZURÜCK ZUM MENÜ", self._show_menu))
        elif self.view_mode == "diagnostic" and self.aligner.phase == "success":
            controls.extend(
                [
                    (self.diagnostic_target_button, "MENÜ", self._show_menu),
                    (self.align_button, "NEU AUSRICHTEN", self.start_alignment),
                    (self.clear_button, "ABLAUF NEU", self.clear_shots),
                    (
                        self.diagnostic_close_button,
                        "PROGRAMM BEENDEN",
                        self._request_program_close,
                    ),
                ]
            )

        selected = nearest_laser_button(
            point,
            ((index, control[0]) for index, control in enumerate(controls)),
        )
        if selected is not None:
            _, label, action = controls[selected]
            LOGGER.info("Laserbedienung: %s bei Bildschirm=%s", label, point)
            action()
            return True
        return False

    def draw(self, fps: float) -> None:
        self._update_cursor_visibility()
        if self.aligner.active:
            self._draw_alignment_pattern()
            return

        if self.view_mode == "menu" and self.aligner.phase == "success":
            self._draw_main_menu()
            return

        standard_game = self._standard_game_for_view()
        if standard_game is not None:
            standard_game.draw()
            return

        if (
            self.view_mode == "chickens"
            and self.aligner.phase == "success"
            and self.chicken_game is not None
        ):
            self.chicken_game.draw()
            return

        if self.view_mode == "coming_soon" and self.aligner.phase == "success":
            self._draw_game_placeholder()
            return

        if self.view_mode == "target" and self.aligner.phase == "success":
            self._draw_sighting_screen()
            return

        self.screen.fill(self.BG)
        self._draw_header(fps)
        preview_rect = self._draw_live_view()
        self._draw_side_panel()
        self._draw_shot_list()
        self._draw_buttons()
        if preview_rect and self.last_detection:
            self._draw_detection_overlay(preview_rect)

    def _draw_main_menu(self) -> None:
        width, height = self.screen.get_size()
        self.screen.fill(self.TARGET_BG)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, self.screen.get_rect(), 7)
        pygame.draw.rect(
            self.screen,
            self.TARGET_MUTED,
            pygame.Rect(14, 14, width - 28, height - 28),
            2,
        )

        title = self.font_menu_title.render("SCHIEßKINO", True, self.TARGET_CYAN)
        self.screen.blit(title, title.get_rect(midtop=(width // 2, 18)))
        subtitle = self.font.render(
            "SPIEL MIT EINEM SCHUSS AUSWÄHLEN", True, self.TARGET_GREEN
        )
        self.screen.blit(subtitle, subtitle.get_rect(midtop=(width // 2, 78)))

        verification = self.aligner.verification
        max_error = verification.max_error if verification is not None else 0.0
        weapon_status = (
            "WAFFE KALIBRIERT" if self.weapon_calibration.active else "WAFFE NICHT KALIBRIERT"
        )
        status_text = self.font_small.render(
            f"✓ LEINWAND BEREIT   ·   4/4 ECKEN   ·   ABWEICHUNG {max_error:.0f} px"
            f"   ·   {weapon_status}",
            True,
            self.TARGET_GREEN,
        )
        status_bg = status_text.get_rect(center=(width // 2, 120)).inflate(24, 10)
        pygame.draw.rect(self.screen, (0, 30, 32), status_bg, border_radius=8)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, status_bg, 1, border_radius=8)
        self.screen.blit(status_text, status_text.get_rect(center=status_bg.center))

        for index, (rect, name, description, available) in enumerate(
            self._menu_entries(), start=1
        ):
            self._draw_game_card(rect, index, name, description, available)

        self._draw_target_button(
            self.menu_sighting_button, "Einschießen", self.TARGET_GREEN
        )
        self._draw_target_button(self.menu_camera_button, "Kamerabild", self.TARGET_CYAN)
        self._draw_target_button(
            self.menu_align_button, "Neu ausrichten", self.TARGET_GREEN
        )

    def _draw_game_card(
        self,
        rect: pygame.Rect,
        number: int,
        name: str,
        description: str,
        available: bool,
    ) -> None:
        border = self.TARGET_GREEN if available else self.TARGET_MUTED
        title_color = self.TARGET_CYAN if available else (0, 150, 190)
        pygame.draw.rect(self.screen, (0, 20, 32), rect, border_radius=12)
        pygame.draw.rect(self.screen, border, rect, 3 if available else 2, border_radius=12)

        number_surface = self.font.render(f"{number:02d}", True, border)
        self.screen.blit(number_surface, (rect.left + 18, rect.top + 14))
        self._draw_menu_aim_point(rect, border)

        card_font = self._fitted_card_font(name, rect.width - 36)
        title = card_font.render(name, True, title_color)
        self.screen.blit(title, (rect.left + 18, rect.top + 60))
        for line_index, line in enumerate(textwrap.wrap(description, width=32)[:2]):
            surface = self.font_small.render(line, True, self.TARGET_MUTED)
            self.screen.blit(surface, (rect.left + 18, rect.top + 101 + line_index * 22))

        status_label = "BEREIT" if available else "IN VORBEREITUNG"
        status_color = self.TARGET_GREEN if available else self.TARGET_MUTED
        status = self.font_small.render(status_label, True, status_color)
        status_rect = status.get_rect(bottomleft=(rect.left + 18, rect.bottom - 16)).inflate(18, 8)
        pygame.draw.rect(self.screen, (0, 31, 38), status_rect, border_radius=6)
        pygame.draw.rect(self.screen, status_color, status_rect, 1, border_radius=6)
        self.screen.blit(status, status.get_rect(center=status_rect.center))

    def _fitted_card_font(self, text: str, max_width: int) -> pygame.font.Font:
        key = (text, max_width)
        cached = self.card_font_cache.get(key)
        if cached is not None:
            return cached
        for size in range(25, 13, -1):
            candidate = pygame.font.SysFont("Arial", size, bold=True)
            if candidate.size(text)[0] <= max_width:
                self.card_font_cache[key] = candidate
                return candidate
        fallback = pygame.font.SysFont("Arial", 13, bold=True)
        self.card_font_cache[key] = fallback
        return fallback

    def _draw_menu_aim_point(
        self, rect: pygame.Rect, color: Tuple[int, int, int]
    ) -> None:
        point = (rect.right - 24, rect.top + 24)
        pygame.draw.circle(self.screen, color, point, 8, 2)
        pygame.draw.line(
            self.screen, color, (point[0] - 12, point[1]), (point[0] + 12, point[1]), 1
        )
        pygame.draw.line(
            self.screen, color, (point[0], point[1] - 12), (point[0], point[1] + 12), 1
        )

    def _draw_game_placeholder(self) -> None:
        width, height = self.screen.get_size()
        self.screen.fill(self.TARGET_BG)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, self.screen.get_rect(), 7)
        card = self._coming_soon_rect()
        pygame.draw.rect(self.screen, (0, 20, 32), card, border_radius=16)
        pygame.draw.rect(self.screen, self.TARGET_CYAN, card, 3, border_radius=16)
        self._draw_menu_aim_point(card, self.TARGET_GREEN)

        heading = self.font_target.render(self.selected_game, True, self.TARGET_CYAN)
        self.screen.blit(heading, heading.get_rect(midtop=(width // 2, card.top + 48)))
        status = self.font_large.render("IN VORBEREITUNG", True, self.TARGET_GREEN)
        self.screen.blit(status, status.get_rect(midtop=(width // 2, card.top + 116)))
        explanation = self.font.render(
            "Dieser Spielmodus wird als Nächstes eingebunden.", True, self.TARGET_MUTED
        )
        self.screen.blit(explanation, explanation.get_rect(midtop=(width // 2, card.top + 171)))
        action = self.font.render(
            "AUF DIESES FENSTER SCHIE\u00dfEN", True, self.TARGET_CYAN
        )
        self.screen.blit(action, action.get_rect(midtop=(width // 2, card.top + 232)))
        back = self.font_small.render("ZURÜCK ZUM MENÜ", True, self.TARGET_GREEN)
        self.screen.blit(back, back.get_rect(midtop=(width // 2, card.top + 271)))

    def _draw_alignment_pattern(self) -> None:
        self.screen.fill(self.aligner.display_color)
        if not self.aligner.shows_markers:
            return

        # Vier kompakte, gut getrennte Flächen liefern eine unabhängige
        # Rückmessung der zuvor berechneten Projektionsabbildung.
        marker_size = max(34, int(min(self.screen.get_size()) * 0.052))
        for point in self.aligner.marker_screen_points:
            marker = pygame.Rect(0, 0, marker_size, marker_size)
            marker.center = point
            pygame.draw.rect(self.screen, (255, 255, 255), marker)

    def _draw_sighting_screen(self) -> None:
        width, height = self.screen.get_size()
        self.screen.fill(self.TARGET_BG)

        # Der Rand macht auf einen Blick sichtbar, ob die gesamte Beamerfläche
        # bis in jede Ecke auf der Leinwand liegt.
        pygame.draw.rect(self.screen, self.TARGET_GREEN, self.screen.get_rect(), 7)
        pygame.draw.rect(
            self.screen,
            self.TARGET_MUTED,
            pygame.Rect(14, 14, width - 28, height - 28),
            2,
        )

        title = self.font_target.render("EINSCHIE\u00dfEN", True, self.TARGET_CYAN)
        self.screen.blit(title, title.get_rect(midtop=(width // 2, 22)))

        verification = self.aligner.verification
        max_error = verification.max_error if verification is not None else 0.0
        badge_text = (
            f"✓ 4/4 ECKEN GEPRÜFT   ·   AUSRICHTUNG {self.aligner.confidence:.0%}"
            f"   ·   GRÖßTE ABWEICHUNG {max_error:.0f} px"
        )
        badge = self.font_small.render(badge_text, True, self.TARGET_GREEN)
        badge_bg = badge.get_rect(center=(width // 2, 91)).inflate(28, 12)
        pygame.draw.rect(self.screen, (0, 30, 32), badge_bg, border_radius=8)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, badge_bg, 1, border_radius=8)
        self.screen.blit(badge, badge.get_rect(center=badge_bg.center))

        for index, point in enumerate(self.aligner.marker_screen_points, start=1):
            self._draw_verified_corner(point, index)

        stages = self._sighting_stages()
        if self.sighting_phase == "complete":
            for _, _, _, point in stages:
                pygame.draw.circle(self.screen, self.TARGET_MUTED, point, 18, 2)
            self._draw_complete_evaluation(stages)
        else:
            name, instruction, required, target_point = stages[self.sighting_step]
            step_text = self.font.render(
                f"SCHRITT {self.sighting_step + 1} VON 5  ·  {name}",
                True,
                self.TARGET_CYAN,
            )
            self.screen.blit(step_text, step_text.get_rect(midtop=(width // 2, 111)))
            prompt = self.font_small.render(instruction, True, self.TARGET_GREEN)
            self.screen.blit(prompt, prompt.get_rect(midtop=(width // 2, 142)))

            if self.sighting_step > 0:
                for index, (_, _, _, point) in enumerate(stages[1:], start=1):
                    if index != self.sighting_step:
                        pygame.draw.circle(self.screen, self.TARGET_MUTED, point, 20, 2)
                        pygame.draw.circle(self.screen, self.TARGET_MUTED, point, 3)

            radius = 178 if self.sighting_step == 0 else 67
            self._draw_target_rings(target_point, radius, active=True)
            self._draw_stage_shots(target_point)

            if self.sighting_phase == "evaluation":
                self._draw_stage_evaluation(stages, target_point)
            else:
                progress = self.font.render(
                    f"{len(self.stage_shots)} VON {required} SCHÜSSEN ERKANNT",
                    True,
                    self.TARGET_CYAN,
                )
                progress_bg = progress.get_rect(
                    center=(width // 2, height - 91)
                ).inflate(24, 10)
                pygame.draw.rect(self.screen, (0, 25, 40), progress_bg, border_radius=7)
                self.screen.blit(progress, progress.get_rect(center=progress_bg.center))

        self._draw_target_button(self.target_menu_button, "Menü", self.TARGET_GREEN)
        self._draw_target_button(self.target_live_button, "Kamerabild", self.TARGET_CYAN)
        self._draw_target_button(
            self.target_align_button, "Neu ausrichten", self.TARGET_GREEN
        )
        self._draw_target_button(
            self.target_clear_button, "Ablauf neu", self.TARGET_CYAN
        )

    def _sighting_stages(
        self,
    ) -> list[tuple[str, str, int, Tuple[int, int]]]:
        width, height = self.screen.get_size()
        corner_x = max(120, int(width * 0.12))
        top_y = max(185, int(height * 0.24))
        bottom_y = min(height - 155, int(height * 0.78))
        return [
            ("MITTE", "FÜNF SCHÜSSE IN DIE MITTE ABGEBEN", 5, (width // 2, height // 2 + 20)),
            ("OBEN LINKS", "DREI SCHÜSSE AUF DIE HERVORGEHOBENE ECKE", 3, (corner_x, top_y)),
            (
                "OBEN RECHTS",
                "DREI SCHÜSSE AUF DIE HERVORGEHOBENE ECKE",
                3,
                (width - corner_x, top_y),
            ),
            (
                "UNTEN RECHTS",
                "DREI SCHÜSSE AUF DIE HERVORGEHOBENE ECKE",
                3,
                (width - corner_x, bottom_y),
            ),
            (
                "UNTEN LINKS",
                "DREI SCHÜSSE AUF DIE HERVORGEHOBENE ECKE",
                3,
                (corner_x, bottom_y),
            ),
        ]

    def _draw_target_rings(
        self, center: Tuple[int, int], radius: int, active: bool = False
    ) -> None:
        pulse = int(3 * np.sin(pygame.time.get_ticks() / 180.0)) if active else 0
        for ring_index, factor in enumerate((1.0, 0.68, 0.37, 0.10)):
            ring_radius = max(7, int(radius * factor) + (pulse if ring_index == 0 else 0))
            color = self.TARGET_CYAN if ring_index in {0, 3} else self.TARGET_GREEN
            pygame.draw.circle(self.screen, color, center, ring_radius, 3 if ring_index == 0 else 2)
        pygame.draw.line(
            self.screen,
            self.TARGET_MUTED,
            (center[0] - radius - 18, center[1]),
            (center[0] + radius + 18, center[1]),
            1,
        )
        pygame.draw.line(
            self.screen,
            self.TARGET_MUTED,
            (center[0], center[1] - radius - 18),
            (center[0], center[1] + radius + 18),
            1,
        )
        pygame.draw.circle(self.screen, self.TARGET_CYAN, center, 3)

    def _draw_stage_shots(self, target_point: Tuple[int, int]) -> None:
        for shot in self.stage_shots:
            if shot.screen_point is None:
                continue
            self._draw_cross(shot.screen_point, self.TARGET_CYAN, 13, 3)
            number = self.font.render(str(shot.number), True, self.TARGET_GREEN)
            self.screen.blit(number, (shot.screen_point[0] + 13, shot.screen_point[1] - 28))

    @staticmethod
    def _group_metrics(
        shots: list[ShotRecord], target_point: Tuple[int, int]
    ) -> tuple[float, float, float]:
        points = np.asarray(
            [shot.screen_point for shot in shots if shot.screen_point is not None],
            dtype=np.float32,
        )
        if not len(points):
            return 0.0, 0.0, 0.0
        mean = points.mean(axis=0)
        delta_x = float(mean[0] - target_point[0])
        delta_y = float(target_point[1] - mean[1])
        spread = 0.0
        for first in points:
            for second in points:
                spread = max(spread, float(np.linalg.norm(first - second)))
        return delta_x, delta_y, spread

    @staticmethod
    def _offset_text(delta_x: float, delta_y: float) -> str:
        horizontal = "mittig" if abs(delta_x) < 1 else (
            f"{abs(delta_x):.0f} px rechts" if delta_x > 0 else f"{abs(delta_x):.0f} px links"
        )
        vertical = "mittig" if abs(delta_y) < 1 else (
            f"{abs(delta_y):.0f} px hoch" if delta_y > 0 else f"{abs(delta_y):.0f} px tief"
        )
        return f"{horizontal}  ·  {vertical}"

    def _draw_stage_evaluation(
        self,
        stages: list[tuple[str, str, int, Tuple[int, int]]],
        target_point: Tuple[int, int],
    ) -> None:
        width, height = self.screen.get_size()
        delta_x, delta_y, spread = self._group_metrics(self.stage_shots, target_point)
        card = self._stage_evaluation_rect()
        pygame.draw.rect(self.screen, (0, 18, 30), card, border_radius=14)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, card, 3, border_radius=14)
        self._draw_evaluation_aim_point(card)

        heading = self.font_large.render("AUSWERTUNG", True, self.TARGET_CYAN)
        self.screen.blit(heading, heading.get_rect(midtop=(card.centerx, card.top + 18)))
        count = self.font.render(
            f"✓ {len(self.stage_shots)} SCHÜSSE VOLLSTÄNDIG",
            True,
            self.TARGET_GREEN,
        )
        self.screen.blit(count, count.get_rect(midtop=(card.centerx, card.top + 63)))
        offset = self.font.render(
            f"Treffpunktlage: {self._offset_text(delta_x, delta_y)}",
            True,
            self.TARGET_CYAN,
        )
        self.screen.blit(offset, offset.get_rect(midtop=(card.centerx, card.top + 100)))
        grouping = self.font.render(
            f"Streukreis: {spread:.0f} px", True, self.TARGET_GREEN
        )
        self.screen.blit(grouping, grouping.get_rect(midtop=(card.centerx, card.top + 134)))

        if self.sighting_step < 4:
            next_name = stages[self.sighting_step + 1][0]
            next_text = f"Hierhin schießen: Weiter zu {next_name}"
        else:
            next_text = "Hierhin schießen: Weiter zur Gesamtauswertung"
        next_surface = self.font_small.render(next_text, True, self.TARGET_MUTED)
        self.screen.blit(next_surface, next_surface.get_rect(midtop=(card.centerx, card.top + 174)))
        self._draw_target_button(
            self.advance_button, "Weiter", self.TARGET_GREEN
        )

    def _draw_complete_evaluation(
        self, stages: list[tuple[str, str, int, Tuple[int, int]]]
    ) -> None:
        width, height = self.screen.get_size()
        card = self._complete_evaluation_rect()
        pygame.draw.rect(self.screen, (0, 18, 30), card, border_radius=14)
        pygame.draw.rect(self.screen, self.TARGET_GREEN, card, 3, border_radius=14)
        self._draw_evaluation_aim_point(card)
        heading = self.font_large.render("GESAMTAUSWERTUNG", True, self.TARGET_CYAN)
        self.screen.blit(heading, heading.get_rect(midtop=(card.centerx, card.top + 18)))
        done = self.font.render("17 SCHÜSSE VOLLSTÄNDIG", True, self.TARGET_GREEN)
        self.screen.blit(done, done.get_rect(midtop=(card.centerx, card.top + 61)))

        for index, (name, _, _, target_point) in enumerate(stages):
            delta_x, delta_y, spread = self._group_metrics(
                self.completed_groups[index], target_point
            )
            line = (
                f"{name:<14}  {self._offset_text(delta_x, delta_y)}"
                f"  ·  Streukreis {spread:.0f} px"
            )
            surface = self.font_small.render(line, True, self.TARGET_CYAN)
            self.screen.blit(surface, (card.left + 34, card.top + 110 + index * 43))

        calibration = self.font_small.render(
            self.weapon_calibration_message,
            True,
            self.TARGET_GREEN if self.weapon_calibration.active else self.TARGET_CYAN,
        )
        self.screen.blit(
            calibration,
            calibration.get_rect(midtop=(card.centerx, card.top + 326)),
        )

        note = self.font_small.render(
            "Auf dieses Fenster schießen: Einschießen wiederholen.",
            True,
            self.TARGET_GREEN,
        )
        self.screen.blit(note, note.get_rect(midtop=(card.centerx, card.bottom - 55)))
        self._draw_target_button(
            self.advance_button, "Einschießen wiederholen", self.TARGET_GREEN
        )

    def _stage_evaluation_rect(self) -> pygame.Rect:
        width, height = self.screen.get_size()
        card = pygame.Rect(0, 0, 610, 244)
        card.center = (width // 2, height // 2 + 25)
        return card

    def _complete_evaluation_rect(self) -> pygame.Rect:
        width, height = self.screen.get_size()
        card = pygame.Rect(0, 0, 660, 410)
        card.center = (width // 2, height // 2 + 32)
        return card

    def _draw_evaluation_aim_point(self, card: pygame.Rect) -> None:
        point = (card.right - 24, card.top + 24)
        pygame.draw.circle(self.screen, self.TARGET_GREEN, point, 8, 2)
        pygame.draw.line(
            self.screen,
            self.TARGET_GREEN,
            (point[0] - 12, point[1]),
            (point[0] + 12, point[1]),
            1,
        )
        pygame.draw.line(
            self.screen,
            self.TARGET_GREEN,
            (point[0], point[1] - 12),
            (point[0], point[1] + 12),
            1,
        )

    def _draw_verified_corner(self, point: Tuple[int, int], number: int) -> None:
        arm = 28
        x, y = point
        left = x < self.screen.get_width() // 2
        top = y < self.screen.get_height() // 2
        horizontal_end = x + arm if left else x - arm
        vertical_end = y + arm if top else y - arm
        pygame.draw.line(self.screen, self.TARGET_GREEN, (x, y), (horizontal_end, y), 4)
        pygame.draw.line(self.screen, self.TARGET_GREEN, (x, y), (x, vertical_end), 4)
        label = self.font_small.render(f"✓ ECKE {number}", True, self.TARGET_GREEN)
        label_rect = label.get_rect()
        label_rect.left = x + 8 if left else x - label_rect.width - 8
        label_rect.top = y + 8 if top else y - label_rect.height - 8
        self.screen.blit(label, label_rect)

    def _draw_target_button(
        self, rect: pygame.Rect, label: str, color: Tuple[int, int, int]
    ) -> None:
        pygame.draw.rect(self.screen, (0, 25, 40), rect, border_radius=7)
        pygame.draw.rect(self.screen, color, rect, 2, border_radius=7)
        self._draw_button_aim_point(rect, color)
        text = self.font_small.render(label, True, color)
        self.screen.blit(text, text.get_rect(center=rect.center))

    def _draw_button_aim_point(
        self, rect: pygame.Rect, color: Tuple[int, int, int]
    ) -> None:
        point = (rect.left + 13, rect.centery)
        pygame.draw.circle(self.screen, color, point, 5, 1)
        pygame.draw.line(self.screen, color, (point[0] - 7, point[1]), (point[0] + 7, point[1]), 1)
        pygame.draw.line(self.screen, color, (point[0], point[1] - 7), (point[0], point[1] + 7), 1)

    def _draw_header(self, fps: float) -> None:
        title = self.font_title.render("LASER ERKENNUNG", True, self.TEXT)
        self.screen.blit(title, (20, 16))
        aligned = self.aligner.homography is not None and self.aligner.phase != "failed"
        status_color = self.GREEN if aligned else self.RED
        if aligned:
            status = f"Ausrichtung {self.aligner.confidence:.0%}"
        elif self.aligner.phase == "failed":
            status = "Kamera neu ausrichten"
        else:
            status = "Nicht ausgerichtet"
        status_surface = self.font.render(status, True, status_color)
        status_rect = status_surface.get_rect(midright=(994, 36))
        pygame.draw.circle(self.screen, status_color, (status_rect.left - 18, 36), 10)
        self.screen.blit(status_surface, status_rect)
        camera_text = (
            f"C922 {self.tracker.actual_width}×{self.tracker.actual_height} "
            f"@ {self.tracker.actual_fps:.0f} fps | Erkennung {self.tracker.processing_fps:.0f} fps "
            f"| Anzeige {fps:.0f} fps"
        )
        self.screen.blit(self.font_small.render(camera_text, True, self.MUTED), (22, 63))

    def _draw_live_view(self) -> Optional[pygame.Rect]:
        outer = pygame.Rect(20, 92, 740, 416)
        pygame.draw.rect(self.screen, self.PANEL, outer, border_radius=8)
        pygame.draw.rect(self.screen, self.BORDER, outer, 2, border_radius=8)
        if self.last_frame_rgb is None:
            text = self.font.render("Warte auf Kamerabild …", True, self.MUTED)
            self.screen.blit(text, text.get_rect(center=outer.center))
            return None

        frame = self.last_frame_rgb
        frame_h, frame_w = frame.shape[:2]
        scale = min((outer.width - 4) / frame_w, (outer.height - 4) / frame_h)
        draw_size = (int(frame_w * scale), int(frame_h * scale))
        view = pygame.Rect(0, 0, *draw_size)
        view.center = outer.center
        surface = pygame.image.frombuffer(frame.tobytes(), (frame_w, frame_h), "RGB").copy()
        surface = pygame.transform.smoothscale(surface, draw_size)
        self.screen.blit(surface, view)
        return view

    def _camera_to_view(self, point: Tuple[int, int], view: pygame.Rect) -> Tuple[int, int]:
        if self.last_frame_rgb is None:
            return view.center
        frame_h, frame_w = self.last_frame_rgb.shape[:2]
        return (
            view.x + int(point[0] * view.width / frame_w),
            view.y + int(point[1] * view.height / frame_h),
        )

    def _draw_detection_overlay(self, view: pygame.Rect) -> None:
        if self.aligner.corners is not None:
            polygon = [
                self._camera_to_view((int(p[0]), int(p[1])), view)
                for p in self.aligner.corners
            ]
            pygame.draw.lines(self.screen, self.GREEN, True, polygon, 3)

        detection = self.last_detection
        if detection and detection.point is not None:
            point = self._camera_to_view(detection.point, view)
            pygame.draw.circle(self.screen, self.YELLOW, point, 7, 2)

        for shot in self.shots:
            point = self._camera_to_view(shot.camera_point, view)
            self._draw_cross(point, self.CYAN, 13, 3)
            label = self.font_small.render(str(shot.number), True, self.TEXT)
            self.screen.blit(label, (point[0] + 9, point[1] - 22))

    def _draw_side_panel(self) -> None:
        panel = pygame.Rect(780, 92, 224, 506)
        pygame.draw.rect(self.screen, self.PANEL, panel, border_radius=8)
        pygame.draw.rect(self.screen, self.BORDER, panel, 2, border_radius=8)
        self.screen.blit(self.font.render("Impulsmaske", True, self.TEXT), (794, 106))

        mask_rect = pygame.Rect(792, 138, 200, 112)
        pygame.draw.rect(self.screen, (0, 0, 0), mask_rect)
        if self.last_mask_rgb is not None:
            mask = self.last_mask_rgb
            mh, mw = mask.shape[:2]
            surf = pygame.image.frombuffer(mask.tobytes(), (mw, mh), "RGB").copy()
            surf = pygame.transform.scale(surf, mask_rect.size)
            self.screen.blit(surf, mask_rect)

        detection = self.last_detection
        lines = [
            f"Punkt: {detection.point if detection else '—'}",
            f"Fläche: {detection.area:.1f}" if detection else "Fläche: —",
            f"Sicherheit: {detection.confidence:.0%}" if detection else "Sicherheit: —",
            f"Rotüberschuss: {detection.peak_red_excess}" if detection else "Rotüberschuss: —",
            f"Bildänderung: {detection.peak_delta}" if detection else "Bildänderung: —",
        ]
        for index, line in enumerate(lines):
            self.screen.blit(self.font_small.render(line, True, self.MUTED), (794, 265 + index * 24))

        target = pygame.Rect(794, 402, 196, 100)
        pygame.draw.rect(self.screen, (9, 12, 18), target)
        pygame.draw.rect(self.screen, self.BORDER, target, 2)
        self.screen.blit(self.font_small.render("Leinwand / letzter Schuss", True, self.TEXT), (796, 375))
        if self.shots and self.shots[-1].screen_point is not None:
            shot = self.shots[-1]
            sw, sh = self.screen.get_size()
            px = target.x + int(shot.screen_point[0] * target.width / sw)
            py = target.y + int(shot.screen_point[1] * target.height / sh)
            self._draw_cross((px, py), self.CYAN, 10, 3)
            coord = self.font_small.render(
                f"x={shot.screen_point[0]}  y={shot.screen_point[1]}", True, self.CYAN
            )
            self.screen.blit(coord, (target.x + 8, target.bottom + 8))

    def _draw_shot_list(self) -> None:
        panel = pygame.Rect(20, 526, 740, 202)
        pygame.draw.rect(self.screen, self.PANEL, panel, border_radius=8)
        pygame.draw.rect(self.screen, self.BORDER, panel, 2, border_radius=8)
        if self.shots:
            headline_color = self.CYAN
            headline = "SCHUSS ERKANNT"
        elif self.aligner.phase == "failed":
            headline_color = self.RED
            headline = "KAMERA AUSRICHTEN"
        else:
            headline_color = self.TEXT
            headline = "Bereit – auf die Leinwand schießen"
        self.screen.blit(self.font_large.render(headline, True, headline_color), (34, 540))

        recent = list(self.shots)[-5:]
        if not recent:
            if self.aligner.phase == "failed":
                wrapped = textwrap.wrap(self.aligner.message, width=72)
                for index, line in enumerate(wrapped[:3]):
                    self.screen.blit(
                        self.font.render(line, True, self.MUTED), (36, 594 + index * 30)
                    )
                return
            hints = [
                "Jeder kurze 620-nm-Impuls wird als einzelne Flanke erkannt.",
                "Blau = aktueller Kandidat, Cyan = bestätigter Schuss.",
            ]
            for index, line in enumerate(hints):
                self.screen.blit(self.font.render(line, True, self.MUTED), (36, 594 + index * 32))
            return

        for index, shot in enumerate(reversed(recent)):
            mapped = shot.screen_point if shot.screen_point is not None else ("—", "—")
            line = (
                f"#{shot.number:02d}  Kamera {shot.camera_point[0]:4d},{shot.camera_point[1]:4d}  "
                f"→ Leinwand {mapped[0]},{mapped[1]}  ({shot.confidence:.0%})"
            )
            color = self.TEXT if index == 0 else self.MUTED
            self.screen.blit(self.font_small.render(line, True, color), (36, 590 + index * 27))

    def _draw_buttons(self) -> None:
        self._draw_button(self.diagnostic_target_button, "Menü", self.CYAN)
        self._draw_button(self.align_button, "Neu ausrichten", self.GREEN)
        self._draw_button(self.clear_button, "Ablauf neu", self.CYAN)
        self._draw_button(self.diagnostic_close_button, "Programm beenden", self.GREEN)

    def _draw_button(self, rect: pygame.Rect, label: str, color: Tuple[int, int, int]) -> None:
        pygame.draw.rect(self.screen, (36, 49, 65), rect, border_radius=7)
        pygame.draw.rect(self.screen, color, rect, 2, border_radius=7)
        self._draw_button_aim_point(rect, color)
        text = self.font_small.render(label, True, self.TEXT)
        self.screen.blit(text, text.get_rect(center=rect.center))

    def _draw_cross(
        self,
        point: Tuple[int, int],
        color: Tuple[int, int, int],
        radius: int,
        width: int,
    ) -> None:
        pygame.draw.circle(self.screen, color, point, radius, width)
        pygame.draw.line(
            self.screen, color, (point[0] - radius - 5, point[1]), (point[0] + radius + 5, point[1]), width
        )
        pygame.draw.line(
            self.screen, color, (point[0], point[1] - radius - 5), (point[0], point[1] + radius + 5), width
        )
